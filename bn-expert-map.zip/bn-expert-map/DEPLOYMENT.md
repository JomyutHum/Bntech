# DEPLOYMENT.md — BN Expert Map

This document describes exactly how each part of the system is deployed.
Read this fully before deploying for the first time.

## Architecture summary

| Component | Hosting | Notes |
|---|---|---|
| Next.js (Admin + Driver web app) | **Vercel** | Auto-deploys from `apps/web` on push to `main` |
| Fastify API + Redis | **Fly.io** | Two services: `bn-expert-map-api`, `bn-expert-map-redis` |
| PostgreSQL database | **Supabase** (managed) | No separate deployment needed — already provisioned |
| File storage (label/slip images) | **Supabase Storage** | Same Supabase project as the database |
| DNS / CDN / WAF | **Cloudflare** | Sits in front of the Vercel domain |

The Fastify backend choice of **Fly.io** here is a concrete, opinionated
pick so this document gives runnable commands rather than generic advice.
If you prefer Railway or a VPS, the Docker image built in
`apps/api/Dockerfile` works on any Docker-capable host — only the
`fly.toml` / `flyctl` commands below would need to be swapped for that
platform's equivalent.

---

## 1. Database — Supabase Postgres (already provisioned)

No deployment action needed — the database already exists as part of your
Supabase project (`yqovxsqcwciozkaegpzi`). What you must do:

1. Get your database password: Supabase Dashboard -> Project Settings ->
   Database -> Database password (reset it if you don't have it).
2. Use that password in both `DATABASE_URL` and `DIRECT_URL` (see
   `apps/api/.env.example`), replacing the `[YOUR-PASSWORD]` placeholder.
3. Run the initial migration against this database:
   ```bash
   cd apps/api
   npm run prisma:migrate
   ```
4. (Optional but recommended) Seed an initial Admin user:
   ```bash
   SEED_ADMIN_EMAIL=you@example.com SEED_ADMIN_PASSWORD=somethingStrong123! npm run prisma:seed
   ```

**Recommendation:** create a second, separate Supabase project for
staging/local-dev once this is past initial testing, so test data never
mixes with production data. Local dev currently points at the same
project as production by default (see `apps/api/.env.example`).

---

## 2. File storage — Supabase Storage (already provisioned)

1. Supabase Dashboard -> Storage -> New bucket.
2. Create a bucket named exactly `bn-expert-map-uploads` (or update
   `SUPABASE_STORAGE_BUCKET` in both `.env` files if you choose a different
   name).
3. Mark it **private** (not public) — the backend reads/writes via the
   service role key and generates signed URLs for Admin UI review.
4. Get the service role key: Supabase Dashboard -> Project Settings -> API ->
   `service_role` secret. Put it in `apps/api/.env` as
   `SUPABASE_SERVICE_ROLE_KEY`. **Never** commit this value or put it in
   `apps/web/.env` (it must never reach the browser).

---

## 3. Backend (Fastify + Redis) — Fly.io

### One-time setup

```bash
# Install flyctl if you haven't: https://fly.io/docs/flyctl/install/
flyctl auth login

cd apps/api
flyctl launch --no-deploy --name bn-expert-map-api
# When prompted, do NOT let flyctl create a Postgres database — we use
# Supabase instead. Do let it skip Redis too; we deploy Redis separately
# below (or use Fly's Redis integration).
```

This generates `apps/api/fly.toml`. Edit it to ensure:

```toml
[build]
  dockerfile = "Dockerfile"

[env]
  PORT = "4000"

[[services]]
  internal_port = 4000
  protocol = "tcp"

  [[services.ports]]
    port = 443
    handlers = ["tls", "http"]
```

### Set secrets (never put real secrets in fly.toml itself)

```bash
flyctl secrets set \
  DATABASE_URL="postgresql://postgres.yqovxsqcwciozkaegpzi:<password>@aws-1-ap-northeast-1.pooler.supabase.com:6543/postgres?pgbouncer=true" \
  DIRECT_URL="postgresql://postgres.yqovxsqcwciozkaegpzi:<password>@aws-1-ap-northeast-1.pooler.supabase.com:5432/postgres" \
  JWT_SECRET="<output of: openssl rand -hex 32>" \
  LINE_CHANNEL_SECRET="<from LINE Developers Console>" \
  LINE_CHANNEL_ACCESS_TOKEN="<from LINE Developers Console>" \
  LINE_LOGIN_CHANNEL_ID="<from LINE Developers Console>" \
  LINE_LOGIN_CHANNEL_SECRET="<from LINE Developers Console>" \
  GOOGLE_APPLICATION_CREDENTIALS_JSON='<paste full JSON contents>' \
  GOOGLE_MAPS_API_KEY="<from Google Cloud Console>" \
  SUPABASE_URL="https://yqovxsqcwciozkaegpzi.supabase.co" \
  SUPABASE_PUBLISHABLE_KEY="sb_publishable_sGVM-2sIeCf-MdbMu-w0dA_xVQfzEVh" \
  SUPABASE_SERVICE_ROLE_KEY="<from Supabase Dashboard>" \
  SUPABASE_STORAGE_BUCKET="bn-expert-map-uploads" \
  --app bn-expert-map-api
```

### Redis on Fly.io

```bash
flyctl redis create --name bn-expert-map-redis
# flyctl will print a connection string — set it as a secret:
flyctl secrets set REDIS_URL="<printed connection string>" --app bn-expert-map-api
```

### Deploy

```bash
flyctl deploy --app bn-expert-map-api
```

### Verify

```bash
curl https://bn-expert-map-api.fly.dev/health
# Expect: {"success":true,"data":{"status":"ok"}}
```

---

## 4. Frontend (Next.js) — Vercel

1. Connect the GitHub repo to a new Vercel project, with **Root Directory**
   set to `apps/web` (Vercel monorepo support).
2. Set environment variables in Vercel project settings (Settings ->
   Environment Variables), matching `apps/web/.env.example`:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
   - `NEXT_PUBLIC_API_BASE_URL` -> set this to your deployed Fly.io URL,
     e.g. `https://bn-expert-map-api.fly.dev`
   - `NEXT_PUBLIC_LINE_LOGIN_CHANNEL_ID`
3. Deploy — Vercel auto-builds on every push to `main`.
4. Once you have a custom domain, also update the Fastify backend's CORS
   origin in `apps/api/src/server.ts` (currently a `REQUIRES_USER_SETUP`
   placeholder of `false` for production) to allow requests from your
   actual Vercel/Cloudflare domain.

---

## 5. Cloudflare (DNS / CDN / WAF)

1. Add your domain to Cloudflare, set nameservers per Cloudflare's
   instructions.
2. Create a CNAME record pointing your domain (e.g. `app.yourdomain.com`)
   to your Vercel deployment's target (Vercel project -> Settings ->
   Domains will show the exact value to use).
3. Set the DNS record's proxy status to **Proxied** (orange cloud) to get
   Cloudflare's CDN/WAF protection in front of Vercel.
4. (Optional) Add a second CNAME/A record for the API
   (`api.yourdomain.com` -> your Fly.io app) if you want a custom domain on
   the backend too, instead of using the `*.fly.dev` URL directly.

---

## 6. LINE Messaging API webhook URL

Once the backend is deployed and reachable:

1. LINE Developers Console -> provider "BN-Expert" -> the Messaging API
   channel (Channel ID `2010517050`) -> Messaging API tab.
2. Set the **Webhook URL** to: `https://bn-expert-map-api.fly.dev/api/v1/line/webhook`
   (or your custom API domain if configured).
3. Click **Verify** — LINE will send a test request; the endpoint should
   respond successfully once `LINE_CHANNEL_SECRET` is correctly set.
4. Enable **Use webhook**.

---

## 7. Complete environment variable checklist

See `apps/api/.env.example` and `apps/web/.env.example` for the full,
commented list. Quick summary of what still needs YOUR input (everything
else is either a safe default or already filled in):

1. Database password (replace `[YOUR-PASSWORD]` in `DATABASE_URL`/`DIRECT_URL`)
2. `JWT_SECRET` (generate via `openssl rand -hex 32`)
3. `LINE_CHANNEL_SECRET`, `LINE_CHANNEL_ACCESS_TOKEN` (Messaging API channel, already created)
4. `LINE_LOGIN_CHANNEL_ID`, `LINE_LOGIN_CHANNEL_SECRET` (create a LINE Login channel)
5. `GOOGLE_APPLICATION_CREDENTIALS_JSON` (Google Cloud service account)
6. `GOOGLE_MAPS_API_KEY` (Google Cloud API key, Distance Matrix + Directions enabled)
7. `SUPABASE_SERVICE_ROLE_KEY` (Supabase Dashboard — keep this secret, server-only)
8. Production `REDIS_URL` (from your Fly.io Redis instance, or equivalent)

---

## 8. Known follow-up items before full production readiness

These are flagged with `REQUIRES_USER_SETUP` or explanatory comments in
the code and should be resolved before relying on this in production:

- **CORS origin** in `apps/api/src/server.ts` is `false` in production by
  default (blocks all browser origins) until you set it to your real
  deployed frontend domain.
- **LINE ID token verification** in `apps/api/src/routes/auth.routes.ts`
  decodes the JWT payload but does not yet verify its signature against
  LINE's JWKS endpoint. Acceptable for initial testing; harden before
  handling real driver accounts at scale.
- **Map-link-then-location two-step flow**: when a driver pastes a map
  link via LINE text message, the current handler acknowledges it but the
  actual link text needs to be temporarily associated with their
  `AwaitingLocationRequest` (e.g. via a short-lived Redis key) so that once
  their live-location follow-up message arrives, the handler can call
  `LocationConfirmationService.fulfill({ awaitingLocationRequestId,
  rawLinkText, driverLiveGps })` — note this call needs no `channel`
  parameter; the service derives `GOOGLE_MAPS_LINK` / `APPLE_MAPS_LINK` /
  `WAZE_LINK` automatically from the link itself. See the inline comment
  in `apps/api/src/routes/line.routes.ts` — `handleTextMessage`. This is
  the one piece of Chapter 4A's map-link path that needs the final wiring
  before it's end-to-end functional; the LINE Location share path is
  already fully wired and uses the exact same underlying service.
