// Shared enums — must stay in sync with apps/api/prisma/schema.prisma

export const PlaceType = {
  HOME: "HOME",
  SHOP: "SHOP",
  COMPANY: "COMPANY",
  CONDO: "CONDO",
  OTHER: "OTHER",
} as const;
export type PlaceType = (typeof PlaceType)[keyof typeof PlaceType];

export const VerificationSource = {
  LINE_LOCATION: "LINE_LOCATION",
  MAP_LINK: "MAP_LINK",
  MANUAL_ADMIN: "MANUAL_ADMIN",
  IMPORTED: "IMPORTED",
} as const;
export type VerificationSource =
  (typeof VerificationSource)[keyof typeof VerificationSource];

export const PlaylistStopStatus = {
  PENDING: "PENDING",
  DELIVERED: "DELIVERED",
  SKIPPED: "SKIPPED",
  PROBLEM: "PROBLEM",
} as const;
export type PlaylistStopStatus =
  (typeof PlaylistStopStatus)[keyof typeof PlaylistStopStatus];

export const OcrJobStatus = {
  PENDING: "PENDING",
  PROCESSED: "PROCESSED",
  NO_MATCH: "NO_MATCH",
  AWAITING_LOCATION: "AWAITING_LOCATION",
  FAILED: "FAILED",
} as const;
export type OcrJobStatus = (typeof OcrJobStatus)[keyof typeof OcrJobStatus];

export const AwaitingLocationStatus = {
  WAITING: "WAITING",
  FULFILLED: "FULFILLED",
  REJECTED_TOO_FAR: "REJECTED_TOO_FAR",
  EXPIRED: "EXPIRED",
} as const;
export type AwaitingLocationStatus =
  (typeof AwaitingLocationStatus)[keyof typeof AwaitingLocationStatus];

export const LocationSubmissionChannel = {
  LINE_LOCATION: "LINE_LOCATION",
  GOOGLE_MAPS_LINK: "GOOGLE_MAPS_LINK",
  APPLE_MAPS_LINK: "APPLE_MAPS_LINK",
  WAZE_LINK: "WAZE_LINK",
} as const;
export type LocationSubmissionChannel =
  (typeof LocationSubmissionChannel)[keyof typeof LocationSubmissionChannel];

export const LocationSubmissionResult = {
  ACCEPTED: "ACCEPTED",
  REJECTED_TOO_FAR: "REJECTED_TOO_FAR",
  REJECTED_UNRESOLVABLE_LINK: "REJECTED_UNRESOLVABLE_LINK",
} as const;
export type LocationSubmissionResult =
  (typeof LocationSubmissionResult)[keyof typeof LocationSubmissionResult];

export const AiMemoryKind = {
  ENTRY_METHOD: "ENTRY_METHOD",
  PICKUP_TIME: "PICKUP_TIME",
  CLOSED_DAY: "CLOSED_DAY",
  LANDMARK_NOTE: "LANDMARK_NOTE",
  HAS_DOG: "HAS_DOG",
  CALL_BEFORE: "CALL_BEFORE",
  BACK_DOOR: "BACK_DOOR",
  ALT_PHONE: "ALT_PHONE",
} as const;
export type AiMemoryKind = (typeof AiMemoryKind)[keyof typeof AiMemoryKind];

/** Proximity threshold for location verification (Chapter 4A).
 *  A single named constant — never hardcode 150 inline elsewhere. */
export const PROXIMITY_THRESHOLD_METERS = 150;

/** Secondary fuzzy-match GPS proximity threshold (Chapter 4, used only
 *  as a supporting signal alongside address-field agreement — never alone). */
export const FUZZY_MATCH_GPS_PROXIMITY_METERS = 150;
