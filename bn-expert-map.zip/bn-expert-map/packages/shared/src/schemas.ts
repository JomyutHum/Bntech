import { z } from "zod";
import {
  PlaceType,
  VerificationSource,
  PlaylistStopStatus,
} from "./enums.js";

// ============================================================
// Common envelope (Chapter 5)
// ============================================================

export interface ApiError {
  code: string;
  message: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: ApiError;
}

export function ok<T>(data: T): ApiResponse<T> {
  return { success: true, data };
}

export function fail(code: string, message: string): ApiResponse<never> {
  return { success: false, error: { code, message } };
}

// ============================================================
// Coordinate schemas
// ============================================================

export const placeTypeEnum = z.enum([
  PlaceType.HOME,
  PlaceType.SHOP,
  PlaceType.COMPANY,
  PlaceType.CONDO,
  PlaceType.OTHER,
]);

export const verificationSourceEnum = z.enum([
  VerificationSource.LINE_LOCATION,
  VerificationSource.MAP_LINK,
  VerificationSource.MANUAL_ADMIN,
  VerificationSource.IMPORTED,
]);

export const createCoordinateSchema = z.object({
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
  houseNumber: z.string().trim().min(1).optional(),
  moo: z.string().trim().optional(),
  soi: z.string().trim().optional(),
  road: z.string().trim().optional(),
  subdistrict: z.string().trim().min(1).optional(),
  district: z.string().trim().min(1).optional(),
  province: z.string().trim().min(1).optional(),
  postalCode: z.string().trim().optional(),
  placeType: placeTypeEnum.default(PlaceType.OTHER),
  landmark: z.string().trim().optional(),
  deliveryTimeNote: z.string().trim().optional(),
  closedDays: z.string().trim().optional(),
  remarks: z.string().trim().optional(),
  tags: z.array(z.string().trim()).default([]),
  verificationSource: verificationSourceEnum,
});
export type CreateCoordinateInput = z.infer<typeof createCoordinateSchema>;

export const updateCoordinateSchema = createCoordinateSchema.partial();
export type UpdateCoordinateInput = z.infer<typeof updateCoordinateSchema>;

export const searchCoordinatesQuerySchema = z.object({
  text: z.string().trim().optional(),
  tag: z.string().trim().optional(),
  minLat: z.coerce.number().optional(),
  maxLat: z.coerce.number().optional(),
  minLng: z.coerce.number().optional(),
  maxLng: z.coerce.number().optional(),
  page: z.coerce.number().int().positive().default(1),
  pageSize: z.coerce.number().int().positive().max(100).default(20),
});
export type SearchCoordinatesQuery = z.infer<
  typeof searchCoordinatesQuerySchema
>;

export const mergeCoordinatesSchema = z.object({
  duplicateCoordinateId: z.string().uuid(),
});
export type MergeCoordinatesInput = z.infer<typeof mergeCoordinatesSchema>;

// ============================================================
// Auth schemas
// ============================================================

export const lineLoginCallbackSchema = z.object({
  code: z.string().min(1),
  redirectUri: z.string().url(),
});
export type LineLoginCallbackInput = z.infer<typeof lineLoginCallbackSchema>;

export const adminLoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});
export type AdminLoginInput = z.infer<typeof adminLoginSchema>;

// ============================================================
// Playlist schemas
// ============================================================

export const playlistStopStatusEnum = z.enum([
  PlaylistStopStatus.PENDING,
  PlaylistStopStatus.DELIVERED,
  PlaylistStopStatus.SKIPPED,
  PlaylistStopStatus.PROBLEM,
]);

export const addPlaylistStopSchema = z.object({
  coordinateId: z.string().uuid(),
});
export type AddPlaylistStopInput = z.infer<typeof addPlaylistStopSchema>;

export const updatePlaylistStopSchema = z.object({
  status: playlistStopStatusEnum,
  problemNote: z.string().trim().optional(),
});
export type UpdatePlaylistStopInput = z.infer<
  typeof updatePlaylistStopSchema
>;

export const todayPlaylistQuerySchema = z.object({
  driverId: z.string().uuid().optional(),
});
export type TodayPlaylistQuery = z.infer<typeof todayPlaylistQuerySchema>;

// ============================================================
// Driver schemas
// ============================================================

export const createDriverSchema = z.object({
  lineUserId: z.string().min(1),
  displayName: z.string().trim().min(1),
  phone: z.string().trim().optional(),
});
export type CreateDriverInput = z.infer<typeof createDriverSchema>;

export const updateDriverSchema = z.object({
  displayName: z.string().trim().min(1).optional(),
  phone: z.string().trim().optional(),
  isActive: z.boolean().optional(),
});
export type UpdateDriverInput = z.infer<typeof updateDriverSchema>;

// ============================================================
// Reports schemas
// ============================================================

export const reportSummaryQuerySchema = z.object({
  from: z.string().datetime(),
  to: z.string().datetime(),
});
export type ReportSummaryQuery = z.infer<typeof reportSummaryQuerySchema>;

// ============================================================
// Pagination helper
// ============================================================

export const paginationQuerySchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  pageSize: z.coerce.number().int().positive().max(100).default(20),
});
export type PaginationQuery = z.infer<typeof paginationQuerySchema>;

export interface PaginatedResult<T> {
  items: T[];
  page: number;
  pageSize: number;
  totalCount: number;
  totalPages: number;
}
