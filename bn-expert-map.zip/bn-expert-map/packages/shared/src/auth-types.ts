export type UserRole = "DRIVER" | "ADMIN";

export interface DriverJwtPayload {
  sub: string; // Driver.id
  role: "DRIVER";
  lineUserId: string;
}

export interface AdminJwtPayload {
  sub: string; // AdminUser.id
  role: "ADMIN";
  email: string;
}

export type JwtPayload = DriverJwtPayload | AdminJwtPayload;

export function isDriverPayload(
  payload: JwtPayload
): payload is DriverJwtPayload {
  return payload.role === "DRIVER";
}

export function isAdminPayload(
  payload: JwtPayload
): payload is AdminJwtPayload {
  return payload.role === "ADMIN";
}
