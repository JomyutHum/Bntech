"use client";

import { useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Leaflet's default marker icons reference image paths that don't resolve
// correctly under Next.js's bundler by default — explicitly reconfigure
// them to use CDN-hosted assets instead of relying on webpack to resolve
// leaflet's internal relative image paths.
const defaultIcon = L.icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

export interface PlaylistMapStop {
  id: string;
  latitude: number;
  longitude: number;
  label: string;
  orderIndex: number;
}

interface PlaylistMapProps {
  stops: PlaylistMapStop[];
  driverPosition?: { latitude: number; longitude: number } | null;
}

function RecenterOnDriver({
  position,
}: {
  position: { latitude: number; longitude: number } | null | undefined;
}) {
  const map = useMap();
  useEffect(() => {
    if (position) {
      map.setView([position.latitude, position.longitude], map.getZoom());
    }
  }, [position, map]);
  return null;
}

export default function PlaylistMap({ stops, driverPosition }: PlaylistMapProps) {
  const center: [number, number] =
    stops.length > 0
      ? [stops[0].latitude, stops[0].longitude]
      : driverPosition
        ? [driverPosition.latitude, driverPosition.longitude]
        : [13.7563, 100.5018]; // Bangkok fallback center

  return (
    <MapContainer
      center={center}
      zoom={14}
      style={{ height: "400px", width: "100%", borderRadius: "0.75rem" }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {stops.map((stop) => (
        <Marker
          key={stop.id}
          position={[stop.latitude, stop.longitude]}
          icon={defaultIcon}
        >
          <Popup>
            {stop.orderIndex + 1}. {stop.label}
          </Popup>
        </Marker>
      ))}
      {driverPosition && (
        <Marker
          position={[driverPosition.latitude, driverPosition.longitude]}
          icon={defaultIcon}
        >
          <Popup>ตำแหน่งของคุณ</Popup>
        </Marker>
      )}
      <RecenterOnDriver position={driverPosition} />
    </MapContainer>
  );
}
