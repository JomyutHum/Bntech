import Link from "next/link";

export default function HomePage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-6 p-8">
      <h1 className="text-3xl font-bold">BN Expert Map</h1>
      <p className="text-gray-600">เลือกส่วนที่ต้องการเข้าใช้งาน</p>
      <div className="flex gap-4">
        <Link
          href="/admin/login"
          className="rounded-lg bg-brand-600 px-6 py-3 text-white hover:bg-brand-700"
        >
          เข้าสู่ระบบ Admin
        </Link>
        <Link
          href="/driver/login"
          className="rounded-lg border border-brand-600 px-6 py-3 text-brand-600 hover:bg-brand-50"
        >
          เข้าสู่ระบบ Driver
        </Link>
      </div>
    </main>
  );
}
