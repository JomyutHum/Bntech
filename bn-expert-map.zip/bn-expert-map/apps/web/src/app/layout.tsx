import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "BN Expert Map",
  description: "Logistics coordinate database & playlist platform",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="th">
      <body>{children}</body>
    </html>
  );
}
