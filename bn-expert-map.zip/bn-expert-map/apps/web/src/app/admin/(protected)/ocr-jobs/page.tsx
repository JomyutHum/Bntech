"use client";

import { useEffect, useState } from "react";
import { apiClient } from "@/lib/api-client";
import type { PaginatedResult } from "@bn-expert-map/shared";

interface OcrJobItem {
  id: string;
  status: string;
  rawExtractedText: string | null;
  normalizedAddressKey: string | null;
  confidenceScore: number | null;
  errorMessage: string | null;
  createdAt: string;
}

export default function OcrJobsPage() {
  const [items, setItems] = useState<OcrJobItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    apiClient
      .get<PaginatedResult<OcrJobItem>>("/api/v1/ocr-jobs?page=1&pageSize=50")
      .then((result) => setItems(result.items))
      .finally(() => setIsLoading(false));
  }, []);

  const statusColor: Record<string, string> = {
    PROCESSED: "text-green-600",
    NO_MATCH: "text-amber-600",
    AWAITING_LOCATION: "text-blue-600",
    FAILED: "text-red-600",
    PENDING: "text-gray-400",
  };

  return (
    <div>
      <h1 className="mb-4 text-2xl font-semibold">OCR Log</h1>

      {isLoading ? (
        <p>กำลังโหลด...</p>
      ) : (
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="border-b text-left">
              <th className="py-2">เวลา</th>
              <th className="py-2">สถานะ</th>
              <th className="py-2">ข้อความที่อ่านได้</th>
              <th className="py-2">ความมั่นใจ</th>
              <th className="py-2">หมายเหตุ</th>
            </tr>
          </thead>
          <tbody>
            {items.map((job) => (
              <tr key={job.id} className="border-b align-top">
                <td className="py-2 whitespace-nowrap">
                  {new Date(job.createdAt).toLocaleString("th-TH")}
                </td>
                <td className={`py-2 font-medium ${statusColor[job.status] ?? ""}`}>
                  {job.status}
                </td>
                <td className="py-2 max-w-md truncate">
                  {job.rawExtractedText ?? "-"}
                </td>
                <td className="py-2">
                  {job.confidenceScore !== null
                    ? `${(job.confidenceScore * 100).toFixed(0)}%`
                    : "-"}
                </td>
                <td className="py-2 text-red-500">{job.errorMessage ?? "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
