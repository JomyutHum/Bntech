"use client";

import { useEffect, useState, useCallback } from "react";
import { apiClient } from "@/lib/api-client";
import type { PaginatedResult } from "@bn-expert-map/shared";

interface CoordinateItem {
  id: string;
  latitude: number;
  longitude: number;
  houseNumber: string | null;
  moo: string | null;
  soi: string | null;
  road: string | null;
  subdistrict: string | null;
  district: string | null;
  province: string | null;
  placeType: string;
  tags: string[];
  verificationSource: string;
  updatedAt: string;
}

interface DuplicateCandidate {
  coordinate: CoordinateItem;
  similarity: number;
  distanceMeters: number | null;
}

export default function CoordinatesPage() {
  const [searchText, setSearchText] = useState("");
  const [items, setItems] = useState<CoordinateItem[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [duplicates, setDuplicates] = useState<DuplicateCandidate[]>([]);

  const loadCoordinates = useCallback(async () => {
    setIsLoading(true);
    try {
      const query = new URLSearchParams({
        page: "1",
        pageSize: "20",
        ...(searchText ? { text: searchText } : {}),
      });
      const result = await apiClient.get<PaginatedResult<CoordinateItem>>(
        `/api/v1/coordinates?${query.toString()}`
      );
      setItems(result.items);
      setTotalCount(result.totalCount);
    } finally {
      setIsLoading(false);
    }
  }, [searchText]);

  useEffect(() => {
    loadCoordinates();
  }, [loadCoordinates]);

  async function viewDuplicates(id: string) {
    setSelectedId(id);
    const candidates = await apiClient.get<DuplicateCandidate[]>(
      `/api/v1/coordinates/${id}/duplicates`
    );
    setDuplicates(candidates);
  }

  async function mergeDuplicate(duplicateId: string) {
    if (!selectedId) return;
    await apiClient.post(`/api/v1/coordinates/${selectedId}/merge`, {
      duplicateCoordinateId: duplicateId,
    });
    setDuplicates((prev) => prev.filter((d) => d.coordinate.id !== duplicateId));
    await loadCoordinates();
  }

  async function deleteCoordinate(id: string) {
    if (!confirm("ยืนยันการลบพิกัดนี้?")) return;
    await apiClient.delete(`/api/v1/coordinates/${id}`);
    await loadCoordinates();
  }

  function formatAddress(c: CoordinateItem): string {
    return [c.houseNumber, c.moo && `หมู่ ${c.moo}`, c.soi && `ซอย ${c.soi}`, c.road, c.subdistrict, c.district, c.province]
      .filter(Boolean)
      .join(" ");
  }

  return (
    <div>
      <h1 className="mb-4 text-2xl font-semibold">ฐานข้อมูลพิกัด</h1>

      <input
        type="text"
        placeholder="ค้นหาที่อยู่..."
        value={searchText}
        onChange={(e) => setSearchText(e.target.value)}
        className="mb-4 w-full max-w-md rounded-md border border-gray-300 px-3 py-2"
      />

      <p className="mb-2 text-sm text-gray-500">พบ {totalCount} รายการ</p>

      {isLoading ? (
        <p>กำลังโหลด...</p>
      ) : (
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="border-b text-left">
              <th className="py-2">ที่อยู่</th>
              <th className="py-2">ประเภท</th>
              <th className="py-2">ที่มา</th>
              <th className="py-2">อัปเดตล่าสุด</th>
              <th className="py-2">การจัดการ</th>
            </tr>
          </thead>
          <tbody>
            {items.map((c) => (
              <tr key={c.id} className="border-b">
                <td className="py-2">{formatAddress(c) || "(ไม่มีข้อมูลที่อยู่)"}</td>
                <td className="py-2">{c.placeType}</td>
                <td className="py-2">{c.verificationSource}</td>
                <td className="py-2">{new Date(c.updatedAt).toLocaleString("th-TH")}</td>
                <td className="py-2 space-x-2">
                  <button
                    onClick={() => viewDuplicates(c.id)}
                    className="text-brand-600 hover:underline"
                  >
                    ดูรายการซ้ำ
                  </button>
                  <button
                    onClick={() => deleteCoordinate(c.id)}
                    className="text-red-600 hover:underline"
                  >
                    ลบ
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {selectedId && (
        <div className="mt-6 rounded-lg border border-amber-300 bg-amber-50 p-4">
          <h2 className="mb-2 font-semibold">รายการที่อาจซ้ำกัน</h2>
          {duplicates.length === 0 ? (
            <p className="text-sm text-gray-600">ไม่พบรายการที่ใกล้เคียง</p>
          ) : (
            <ul className="space-y-2">
              {duplicates.map((d) => (
                <li
                  key={d.coordinate.id}
                  className="flex items-center justify-between rounded-md bg-white p-2"
                >
                  <span className="text-sm">
                    {formatAddress(d.coordinate)} — ความคล้าย{" "}
                    {(d.similarity * 100).toFixed(0)}%
                    {d.distanceMeters !== null &&
                      ` (ห่าง ${Math.round(d.distanceMeters)}m)`}
                  </span>
                  <button
                    onClick={() => mergeDuplicate(d.coordinate.id)}
                    className="rounded-md bg-brand-600 px-3 py-1 text-xs text-white"
                  >
                    รวมรายการนี้
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
