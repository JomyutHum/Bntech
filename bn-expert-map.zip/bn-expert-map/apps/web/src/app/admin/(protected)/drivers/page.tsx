"use client";

import { useEffect, useState, useCallback } from "react";
import { apiClient } from "@/lib/api-client";
import type { PaginatedResult } from "@bn-expert-map/shared";

interface DriverItem {
  id: string;
  lineUserId: string;
  displayName: string;
  phone: string | null;
  isActive: boolean;
  createdAt: string;
}

export default function DriversPage() {
  const [items, setItems] = useState<DriverItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [newLineUserId, setNewLineUserId] = useState("");
  const [newDisplayName, setNewDisplayName] = useState("");

  const loadDrivers = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await apiClient.get<PaginatedResult<DriverItem>>(
        "/api/v1/drivers?page=1&pageSize=50"
      );
      setItems(result.items);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDrivers();
  }, [loadDrivers]);

  async function addDriver(e: React.FormEvent) {
    e.preventDefault();
    await apiClient.post("/api/v1/drivers", {
      lineUserId: newLineUserId,
      displayName: newDisplayName,
    });
    setNewLineUserId("");
    setNewDisplayName("");
    await loadDrivers();
  }

  async function toggleActive(driver: DriverItem) {
    await apiClient.patch(`/api/v1/drivers/${driver.id}`, {
      isActive: !driver.isActive,
    });
    await loadDrivers();
  }

  return (
    <div>
      <h1 className="mb-4 text-2xl font-semibold">คนขับ</h1>

      <form onSubmit={addDriver} className="mb-6 flex gap-2">
        <input
          placeholder="LINE User ID"
          value={newLineUserId}
          onChange={(e) => setNewLineUserId(e.target.value)}
          required
          className="rounded-md border border-gray-300 px-3 py-2"
        />
        <input
          placeholder="ชื่อที่แสดง"
          value={newDisplayName}
          onChange={(e) => setNewDisplayName(e.target.value)}
          required
          className="rounded-md border border-gray-300 px-3 py-2"
        />
        <button
          type="submit"
          className="rounded-md bg-brand-600 px-4 py-2 text-white"
        >
          เพิ่มคนขับ
        </button>
      </form>

      {isLoading ? (
        <p>กำลังโหลด...</p>
      ) : (
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="border-b text-left">
              <th className="py-2">ชื่อ</th>
              <th className="py-2">LINE User ID</th>
              <th className="py-2">เบอร์โทร</th>
              <th className="py-2">สถานะ</th>
              <th className="py-2">การจัดการ</th>
            </tr>
          </thead>
          <tbody>
            {items.map((d) => (
              <tr key={d.id} className="border-b">
                <td className="py-2">{d.displayName}</td>
                <td className="py-2 font-mono text-xs">{d.lineUserId}</td>
                <td className="py-2">{d.phone ?? "-"}</td>
                <td className="py-2">
                  <span
                    className={
                      d.isActive ? "text-green-600" : "text-gray-400"
                    }
                  >
                    {d.isActive ? "ใช้งานอยู่" : "ปิดใช้งาน"}
                  </span>
                </td>
                <td className="py-2">
                  <button
                    onClick={() => toggleActive(d)}
                    className="text-brand-600 hover:underline"
                  >
                    {d.isActive ? "ปิดใช้งาน" : "เปิดใช้งาน"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
