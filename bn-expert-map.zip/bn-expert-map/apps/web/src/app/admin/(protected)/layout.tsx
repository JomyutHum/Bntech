"use client";

import Link from "next/link";
import { useAuthGuard } from "@/lib/use-auth-guard";

const NAV_ITEMS = [
  { href: "/admin/coordinates", label: "ฐานข้อมูลพิกัด" },
  { href: "/admin/drivers", label: "คนขับ" },
  { href: "/admin/playlists", label: "Playlist" },
  { href: "/admin/ocr-jobs", label: "OCR Log" },
  { href: "/admin/audit-logs", label: "Audit Log" },
];

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { isChecking } = useAuthGuard("/admin/login");

  if (isChecking) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p>กำลังตรวจสอบสิทธิ์...</p>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen">
      <aside className="w-56 border-r border-gray-200 p-4">
        <h2 className="mb-6 text-lg font-bold">BN Expert Map</h2>
        <nav className="flex flex-col gap-2">
          {NAV_ITEMS.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-md px-3 py-2 text-sm hover:bg-gray-100"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>
      <main className="flex-1 p-6">{children}</main>
    </div>
  );
}
