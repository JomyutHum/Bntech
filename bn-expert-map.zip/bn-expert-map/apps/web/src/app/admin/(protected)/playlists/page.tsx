"use client";

import { useState } from "react";
import { apiClient } from "@/lib/api-client";

interface PlaylistStopItem {
  id: string;
  status: string;
  distanceMeters: number | null;
  etaMinutes: number | null;
  coordinate: {
    soi: string | null;
    road: string | null;
    subdistrict: string | null;
    district: string | null;
  };
}

interface PlaylistResponse {
  id: string;
  driverId: string;
  playlistDate: string;
  stops: PlaylistStopItem[];
}

export default function PlaylistsPage() {
  const [driverId, setDriverId] = useState("");
  const [playlist, setPlaylist] = useState<PlaylistResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function loadPlaylist(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      const result = await apiClient.get<PlaylistResponse>(
        `/api/v1/playlists/today?driverId=${driverId}`
      );
      setPlaylist(result);
    } catch {
      setError("ไม่พบ Playlist สำหรับคนขับนี้");
      setPlaylist(null);
    }
  }

  return (
    <div>
      <h1 className="mb-4 text-2xl font-semibold">Playlist ของคนขับ</h1>

      <form onSubmit={loadPlaylist} className="mb-6 flex gap-2">
        <input
          placeholder="Driver ID"
          value={driverId}
          onChange={(e) => setDriverId(e.target.value)}
          required
          className="rounded-md border border-gray-300 px-3 py-2"
        />
        <button
          type="submit"
          className="rounded-md bg-brand-600 px-4 py-2 text-white"
        >
          ดู Playlist วันนี้
        </button>
      </form>

      {error && <p className="text-red-600">{error}</p>}

      {playlist && (
        <div>
          <p className="mb-2 text-sm text-gray-500">
            วันที่ {new Date(playlist.playlistDate).toLocaleDateString("th-TH")} —{" "}
            {playlist.stops.length} จุดที่เหลือ
          </p>
          <ol className="space-y-2">
            {playlist.stops.map((stop, idx) => (
              <li
                key={stop.id}
                className="rounded-md border border-gray-200 p-3"
              >
                <span className="mr-2 font-semibold">{idx + 1}.</span>
                {[stop.coordinate.soi, stop.coordinate.road, stop.coordinate.subdistrict, stop.coordinate.district]
                  .filter(Boolean)
                  .join(" ")}
                {stop.distanceMeters !== null && (
                  <span className="ml-2 text-xs text-gray-500">
                    ({(stop.distanceMeters / 1000).toFixed(1)} กม. •{" "}
                    {stop.etaMinutes} นาที)
                  </span>
                )}
              </li>
            ))}
          </ol>
        </div>
      )}
    </div>
  );
}
