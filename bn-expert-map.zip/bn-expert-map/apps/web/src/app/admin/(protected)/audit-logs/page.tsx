"use client";

import { useEffect, useState } from "react";
import { apiClient } from "@/lib/api-client";
import type { PaginatedResult } from "@bn-expert-map/shared";

interface AuditLogItem {
  id: string;
  actorType: string;
  actorId: string;
  entityType: string;
  entityId: string;
  action: string;
  createdAt: string;
}

export default function AuditLogsPage() {
  const [items, setItems] = useState<AuditLogItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    apiClient
      .get<PaginatedResult<AuditLogItem>>("/api/v1/audit-logs?page=1&pageSize=50")
      .then((result) => setItems(result.items))
      .finally(() => setIsLoading(false));
  }, []);

  return (
    <div>
      <h1 className="mb-4 text-2xl font-semibold">Audit Log</h1>

      {isLoading ? (
        <p>กำลังโหลด...</p>
      ) : (
        <table className="w-full border-collapse text-sm">
          <thead>
            <tr className="border-b text-left">
              <th className="py-2">เวลา</th>
              <th className="py-2">ผู้ทำรายการ</th>
              <th className="py-2">รายการ</th>
              <th className="py-2">การกระทำ</th>
            </tr>
          </thead>
          <tbody>
            {items.map((log) => (
              <tr key={log.id} className="border-b">
                <td className="py-2 whitespace-nowrap">
                  {new Date(log.createdAt).toLocaleString("th-TH")}
                </td>
                <td className="py-2">
                  {log.actorType} ({log.actorId.slice(0, 8)})
                </td>
                <td className="py-2">
                  {log.entityType} #{log.entityId.slice(0, 8)}
                </td>
                <td className="py-2">{log.action}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
