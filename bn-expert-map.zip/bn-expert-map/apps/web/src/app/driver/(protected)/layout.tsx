"use client";

import { useAuthGuard } from "@/lib/use-auth-guard";

export default function DriverProtectedLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { isChecking } = useAuthGuard("/driver/login");

  if (isChecking) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p>กำลังตรวจสอบสิทธิ์...</p>
      </div>
    );
  }

  return <>{children}</>;
}
