"use client";

import { useEffect, useState, useCallback } from "react";
import dynamic from "next/dynamic";
import { apiClient } from "@/lib/api-client";

const PlaylistMap = dynamic(() => import("@/components/PlaylistMap"), {
  ssr: false,
  loading: () => (
    <div className="flex h-[400px] items-center justify-center rounded-xl bg-gray-100">
      กำลังโหลดแผนที่...
    </div>
  ),
});

interface PlaylistStopItem {
  id: string;
  status: string;
  distanceMeters: number | null;
  etaMinutes: number | null;
  coordinate: {
    latitude: number;
    longitude: number;
    soi: string | null;
    road: string | null;
    subdistrict: string | null;
    district: string | null;
    landmark: string | null;
  };
}

interface PlaylistResponse {
  id: string;
  stops: PlaylistStopItem[];
}

function formatStopLabel(stop: PlaylistStopItem): string {
  const c = stop.coordinate;
  return (
    [c.soi && `ซอย${c.soi}`, c.road, c.subdistrict, c.district]
      .filter(Boolean)
      .join(" ") || "(ไม่มีชื่อที่อยู่)"
  );
}

export default function DriverPlaylistPage() {
  const [playlist, setPlaylist] = useState<PlaylistResponse | null>(null);
  const [viewMode, setViewMode] = useState<"map" | "list">("list");
  const [driverPosition, setDriverPosition] = useState<{
    latitude: number;
    longitude: number;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const loadPlaylist = useCallback(async () => {
    setIsLoading(true);
    try {
      const result = await apiClient.get<PlaylistResponse>(
        "/api/v1/playlists/today"
      );
      setPlaylist(result);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadPlaylist();

    if (typeof navigator !== "undefined" && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) =>
          setDriverPosition({
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
          }),
        () => {
          /* permission denied — map falls back to stop-centered view */
        }
      );
    }
  }, [loadPlaylist]);

  async function markStopStatus(
    stopId: string,
    status: "DELIVERED" | "SKIPPED" | "PROBLEM"
  ) {
    if (!playlist) return;
    await apiClient.patch(
      `/api/v1/playlists/${playlist.id}/stops/${stopId}`,
      { status }
    );
    // Per spec: completed/skipped stops disappear from the active view
    // immediately.
    await loadPlaylist();
  }

  if (isLoading) {
    return (
      <main className="p-6">
        <p>กำลังโหลด...</p>
      </main>
    );
  }

  const stops = playlist?.stops ?? [];

  return (
    <main className="mx-auto max-w-2xl p-4">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-xl font-bold">งานวันนี้ ({stops.length} จุด)</h1>
        <div className="flex gap-2">
          <button
            onClick={() => setViewMode("list")}
            className={`rounded-md px-3 py-1 text-sm ${
              viewMode === "list" ? "bg-brand-600 text-white" : "bg-gray-100"
            }`}
          >
            รายการ
          </button>
          <button
            onClick={() => setViewMode("map")}
            className={`rounded-md px-3 py-1 text-sm ${
              viewMode === "map" ? "bg-brand-600 text-white" : "bg-gray-100"
            }`}
          >
            แผนที่
          </button>
        </div>
      </div>

      {stops.length === 0 ? (
        <p className="text-gray-500">ไม่มีงานเหลือแล้ววันนี้ 🎉</p>
      ) : viewMode === "map" ? (
        <PlaylistMap
          stops={stops.map((s, idx) => ({
            id: s.id,
            latitude: s.coordinate.latitude,
            longitude: s.coordinate.longitude,
            label: formatStopLabel(s),
            orderIndex: idx,
          }))}
          driverPosition={driverPosition}
        />
      ) : (
        <ul className="space-y-3">
          {stops.map((stop, idx) => (
            <li
              key={stop.id}
              className="rounded-xl border border-gray-200 p-4 shadow-sm"
            >
              <div className="mb-2 flex items-start justify-between">
                <div>
                  <span className="mr-2 font-bold text-brand-600">
                    {idx + 1}.
                  </span>
                  <span className="font-medium">{formatStopLabel(stop)}</span>
                  {stop.coordinate.landmark && (
                    <p className="text-xs text-gray-500">
                      จุดสังเกต: {stop.coordinate.landmark}
                    </p>
                  )}
                </div>
                {stop.distanceMeters !== null && (
                  <span className="whitespace-nowrap text-xs text-gray-500">
                    {(stop.distanceMeters / 1000).toFixed(1)} กม. •{" "}
                    {stop.etaMinutes} นาที
                  </span>
                )}
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => markStopStatus(stop.id, "DELIVERED")}
                  className="flex-1 rounded-md bg-green-600 py-2 text-sm text-white"
                >
                  ส่งแล้ว
                </button>
                <button
                  onClick={() => markStopStatus(stop.id, "SKIPPED")}
                  className="flex-1 rounded-md bg-gray-400 py-2 text-sm text-white"
                >
                  ข้าม
                </button>
                <button
                  onClick={() => markStopStatus(stop.id, "PROBLEM")}
                  className="flex-1 rounded-md bg-red-500 py-2 text-sm text-white"
                >
                  มีปัญหา
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}
