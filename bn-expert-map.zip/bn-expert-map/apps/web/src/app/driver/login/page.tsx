"use client";

import { useEffect } from "react";

const LINE_LOGIN_CHANNEL_ID = process.env.NEXT_PUBLIC_LINE_LOGIN_CHANNEL_ID ?? "";

export default function DriverLoginPage() {
  function redirectToLineLogin() {
    const redirectUri =
      typeof window !== "undefined"
        ? `${window.location.origin}/driver/login/callback`
        : "";

    const state = Math.random().toString(36).slice(2);
    if (typeof window !== "undefined") {
      window.sessionStorage.setItem("line_login_state", state);
    }

    const params = new URLSearchParams({
      response_type: "code",
      client_id: LINE_LOGIN_CHANNEL_ID,
      redirect_uri: redirectUri,
      state,
      scope: "profile openid",
    });

    window.location.href = `https://access.line.me/oauth2/v2.1/authorize?${params.toString()}`;
  }

  return (
    <main className="flex min-h-screen flex-col items-center justify-center gap-6 p-8">
      <h1 className="text-2xl font-bold">เข้าสู่ระบบสำหรับคนขับ</h1>
      <button
        onClick={redirectToLineLogin}
        className="rounded-lg bg-[#06C755] px-6 py-3 font-medium text-white hover:opacity-90"
      >
        เข้าสู่ระบบด้วย LINE
      </button>
    </main>
  );
}
