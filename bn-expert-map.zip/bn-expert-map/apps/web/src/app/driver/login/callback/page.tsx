"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { apiClient, setStoredToken, ApiClientError } from "@/lib/api-client";

interface LineLoginResponse {
  token: string;
  driver: { id: string; displayName: string };
}

/**
 * Next.js App Router requires any Client Component calling
 * useSearchParams() to be wrapped in a <Suspense> boundary, otherwise the
 * page is forced into fully dynamic rendering with a build-time warning.
 * The actual logic lives in CallbackHandler; this default export just
 * supplies the boundary.
 */
export default function DriverLoginCallbackPage() {
  return (
    <Suspense
      fallback={
        <main className="flex min-h-screen items-center justify-center p-8">
          <p>กำลังเข้าสู่ระบบ...</p>
        </main>
      }
    >
      <CallbackHandler />
    </Suspense>
  );
}

function CallbackHandler() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const code = searchParams.get("code");
    const state = searchParams.get("state");
    const expectedState =
      typeof window !== "undefined"
        ? window.sessionStorage.getItem("line_login_state")
        : null;

    if (!code) {
      setError("ไม่พบรหัสยืนยันจาก LINE กรุณาลองเข้าสู่ระบบใหม่");
      return;
    }

    if (!state || state !== expectedState) {
      setError("การยืนยันตัวตนไม่ถูกต้อง กรุณาลองเข้าสู่ระบบใหม่");
      return;
    }

    const redirectUri = `${window.location.origin}/driver/login/callback`;

    apiClient
      .post<LineLoginResponse>("/api/v1/auth/line/callback", {
        code,
        redirectUri,
      })
      .then((result) => {
        setStoredToken(result.token);
        router.push("/driver/playlist");
      })
      .catch((err) => {
        if (err instanceof ApiClientError) {
          setError(err.message);
        } else {
          setError("เข้าสู่ระบบไม่สำเร็จ กรุณาลองใหม่");
        }
      });
  }, [searchParams, router]);

  return (
    <main className="flex min-h-screen items-center justify-center p-8">
      {error ? (
        <p className="text-red-600">{error}</p>
      ) : (
        <p>กำลังเข้าสู่ระบบ...</p>
      )}
    </main>
  );
}
