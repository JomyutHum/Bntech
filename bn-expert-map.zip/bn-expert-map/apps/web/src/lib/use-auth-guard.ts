"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { getStoredToken } from "./api-client";

/**
 * Client-side auth guard for Admin/Driver pages. Redirects to the given
 * login path if no token is present in localStorage. This is a UX
 * convenience layer only — the real security boundary is the backend's
 * requireAuth/requireAdmin/requireDriver middleware, which independently
 * verifies the JWT on every API request regardless of what this hook
 * does client-side.
 */
export function useAuthGuard(loginPath: string): { isChecking: boolean } {
  const router = useRouter();
  const [isChecking, setIsChecking] = useState(true);

  useEffect(() => {
    const token = getStoredToken();
    if (!token) {
      router.replace(loginPath);
      return;
    }
    setIsChecking(false);
  }, [router, loginPath]);

  return { isChecking };
}
