/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  transpilePackages: ["@bn-expert-map/shared"],
};

export default nextConfig;
