import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

/**
 * Seed script — creates one initial AdminUser so the Admin dashboard has
 * a way to log in on a fresh database. Run with: npm run prisma:seed
 * (after setting SEED_ADMIN_EMAIL / SEED_ADMIN_PASSWORD env vars, or it
 * falls back to a clearly-temporary default that MUST be changed).
 */
async function main(): Promise<void> {
  const email = process.env.SEED_ADMIN_EMAIL ?? "admin@bn-expert-map.local";
  const password = process.env.SEED_ADMIN_PASSWORD ?? "ChangeMeImmediately123!";

  const existing = await prisma.adminUser.findUnique({ where: { email } });
  if (existing) {
    console.log(`Admin user ${email} already exists — skipping seed.`);
    return;
  }

  const passwordHash = await bcrypt.hash(password, 12);

  await prisma.adminUser.create({
    data: {
      email,
      passwordHash,
      displayName: "Initial Admin",
    },
  });

  console.log(`Created initial admin user: ${email}`);
  console.log(
    "REQUIRES_USER_SETUP: log in and change this password immediately " +
      "if you used the default value."
  );
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
