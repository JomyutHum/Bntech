import type { PrismaClient, Coordinate } from "@prisma/client";
import {
  buildNormalizedAddressKey,
  fuzzyAddressSimilarity,
  type AddressFields,
} from "../utils/address-normalizer.js";
import { haversineDistanceMeters, type LatLng } from "../utils/geo.js";
import { FUZZY_MATCH_GPS_PROXIMITY_METERS } from "@bn-expert-map/shared";

/**
 * CoordinateMatchingService — Chapter 4 (CRITICAL).
 *
 * Matching priority:
 *  1. PRIMARY: exact normalizedAddressKey match -> immediate match.
 *  2. SECONDARY: fuzzy address match + GPS proximity as a *supporting*
 *     signal -> surfaced as "possible duplicate, needs human confirmation",
 *     never auto-matched.
 *  3. GPS proximity alone is NEVER sufficient to call two records the same
 *     address.
 *  4. No primary/secondary match -> NO_MATCH.
 */

const FUZZY_SIMILARITY_THRESHOLD = 0.5;

export type MatchResultType = "EXACT_MATCH" | "POSSIBLE_DUPLICATE" | "NO_MATCH";

export interface MatchCandidate {
  coordinate: Coordinate;
  similarity: number;
  distanceMeters: number | null;
}

export interface MatchResult {
  type: MatchResultType;
  exactMatch?: Coordinate;
  candidates?: MatchCandidate[];
}

export class CoordinateMatchingService {
  constructor(private readonly prisma: PrismaClient) {}

  /**
   * Finds the matching coordinate (or candidates) for the given address
   * fields, optionally using a GPS hint as a supporting signal.
   */
  async findMatch(
    addressFields: AddressFields,
    gpsHint?: LatLng | null
  ): Promise<MatchResult> {
    const normalizedKey = buildNormalizedAddressKey(addressFields);

    if (normalizedKey.length === 0) {
      // Nothing usable to match on — never fall back to GPS-only matching.
      return { type: "NO_MATCH" };
    }

    // --- PRIMARY: exact key match ---
    const exact = await this.prisma.coordinate.findFirst({
      where: { normalizedAddressKey: normalizedKey },
      orderBy: { updatedAt: "desc" },
    });

    if (exact) {
      return { type: "EXACT_MATCH", exactMatch: exact };
    }

    // --- SECONDARY: fuzzy address match, optionally supported by GPS ---
    const candidates = await this.findFuzzyCandidates(normalizedKey, gpsHint);

    if (candidates.length > 0) {
      return { type: "POSSIBLE_DUPLICATE", candidates };
    }

    return { type: "NO_MATCH" };
  }

  /**
   * Finds fuzzy address-match candidates. GPS proximity (if provided) is
   * used only to rank/annotate candidates that ALREADY passed the address
   * similarity threshold — it is never used to find candidates on its own.
   */
  private async findFuzzyCandidates(
    normalizedKey: string,
    gpsHint?: LatLng | null
  ): Promise<MatchCandidate[]> {
    // Pull a bounded working set to score in-process. In production this
    // should be narrowed further with a trigram/GIN index on
    // normalizedAddressKey, but the similarity scoring itself must remain
    // address-first per Chapter 4.
    const workingSet = await this.prisma.coordinate.findMany({
      take: 200,
      orderBy: { updatedAt: "desc" },
    });

    const scored: MatchCandidate[] = [];

    for (const candidate of workingSet) {
      const similarity = fuzzyAddressSimilarity(
        normalizedKey,
        candidate.normalizedAddressKey
      );

      if (similarity < FUZZY_SIMILARITY_THRESHOLD) {
        continue;
      }

      let distanceMeters: number | null = null;
      if (gpsHint) {
        distanceMeters = haversineDistanceMeters(gpsHint, {
          latitude: candidate.latitude,
          longitude: candidate.longitude,
        });
      }

      scored.push({ coordinate: candidate, similarity, distanceMeters });
    }

    // Rank: address similarity first, GPS proximity only as a tie-breaker.
    scored.sort((a, b) => {
      if (b.similarity !== a.similarity) return b.similarity - a.similarity;
      const distA = a.distanceMeters ?? Number.POSITIVE_INFINITY;
      const distB = b.distanceMeters ?? Number.POSITIVE_INFINITY;
      return distA - distB;
    });

    return scored.slice(0, 10);
  }

  /**
   * Returns true if a fuzzy candidate's GPS distance is within the
   * secondary confirming threshold. This is informational only — it must
   * NEVER be used to auto-promote a fuzzy match to an exact match.
   */
  isGpsSupportingSignal(distanceMeters: number | null): boolean {
    if (distanceMeters === null) return false;
    return distanceMeters <= FUZZY_MATCH_GPS_PROXIMITY_METERS;
  }
}
