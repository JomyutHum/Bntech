import { PROXIMITY_THRESHOLD_METERS } from "@bn-expert-map/shared";
import { haversineDistanceMeters, type LatLng } from "../utils/geo.js";

/**
 * ProximityVerificationService — Chapter 4A (CRITICAL).
 *
 * This is the safeguard that keeps the "never guess coordinates" principle
 * intact while allowing multiple location-submission channels (LINE
 * Location share, map links). A submitted candidate coordinate is only
 * ever accepted as VERIFIED if the driver's live GPS reading at submission
 * time is within PROXIMITY_THRESHOLD_METERS of it.
 *
 * The threshold is inclusive: distance <= 150m accepts.
 */

export type ProximityCheckOutcome = "ACCEPTED" | "REJECTED_TOO_FAR";

export interface ProximityCheckResult {
  outcome: ProximityCheckOutcome;
  distanceMeters: number;
}

export class MissingLiveGpsReadingError extends Error {
  constructor() {
    super(
      "Cannot verify proximity without a live GPS reading from the driver. " +
        "Never accept a candidate coordinate without a comparison point."
    );
    this.name = "MissingLiveGpsReadingError";
  }
}

export class ProximityVerificationService {
  constructor(
    private readonly thresholdMeters: number = PROXIMITY_THRESHOLD_METERS
  ) {}

  /**
   * Verifies that a candidate coordinate is within the proximity threshold
   * of the driver's live GPS reading.
   *
   * @throws MissingLiveGpsReadingError if driverLiveGps is not provided —
   *   this must never silently pass as "accepted".
   */
  verify(candidate: LatLng, driverLiveGps: LatLng | null): ProximityCheckResult {
    if (!driverLiveGps) {
      throw new MissingLiveGpsReadingError();
    }

    const distanceMeters = haversineDistanceMeters(candidate, driverLiveGps);
    const outcome: ProximityCheckOutcome =
      distanceMeters <= this.thresholdMeters ? "ACCEPTED" : "REJECTED_TOO_FAR";

    return { outcome, distanceMeters };
  }
}
