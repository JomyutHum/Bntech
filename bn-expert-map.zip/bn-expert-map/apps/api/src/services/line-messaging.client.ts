// REQUIRES_VERIFICATION: this import shape (`messagingApi.MessagingApiClient`
// from @line/bot-sdk v9.x) was written from memory without network access
// to confirm against the published package. Before relying on this in
// production, run `npm install` and check this still matches the actual
// package exports — if @line/bot-sdk's API differs, the fix is localized
// to this file and line-webhook signature verification (which does NOT
// depend on this SDK) is unaffected.
import { messagingApi } from "@line/bot-sdk";
import { loadEnv } from "../config/env.js";

const { MessagingApiClient } = messagingApi;

let client: messagingApi.MessagingApiClient | null = null;

function getClient(): messagingApi.MessagingApiClient {
  if (client) return client;
  const env = loadEnv();
  client = new MessagingApiClient({
    channelAccessToken: env.LINE_CHANNEL_ACCESS_TOKEN,
  });
  return client;
}

export class LineMessagingClient {
  async replyText(replyToken: string, text: string): Promise<void> {
    await getClient().replyMessage({
      replyToken,
      messages: [{ type: "text", text }],
    });
  }

  async replyWithQuickReply(
    replyToken: string,
    text: string,
    quickReplyLabels: { label: string; data: string }[]
  ): Promise<void> {
    await getClient().replyMessage({
      replyToken,
      messages: [
        {
          type: "text",
          text,
          quickReply: {
            items: quickReplyLabels.map((item) => ({
              type: "action",
              action: {
                type: "postback",
                label: item.label,
                data: item.data,
                displayText: item.label,
              },
            })),
          },
        },
      ],
    });
  }

  async requestLocation(replyToken: string, prompt: string): Promise<void> {
    // LINE's Messaging API does not support directly "pulling" a location
    // on demand; the standard pattern is to prompt the user with a text
    // message asking them to use LINE's location-share UI (the location
    // share icon in their chat input), per Chapter 4A.
    await this.replyText(
      replyToken,
      `${prompt}\n\n(แชร์พิกัดผ่านไอคอนแชร์ตำแหน่งใน LINE หรือแปะลิงก์แผนที่มาได้เลยครับ)`
    );
  }

  async pushText(lineUserId: string, text: string): Promise<void> {
    await getClient().pushMessage({
      to: lineUserId,
      messages: [{ type: "text", text }],
    });
  }
}
