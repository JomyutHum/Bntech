import { loadEnv } from "../config/env.js";
import type { LatLng } from "../utils/geo.js";

export interface DistanceMatrixResult {
  distanceMeters: number;
  durationSeconds: number;
}

/**
 * GoogleMapsService — Distance Matrix / Directions integration.
 * Used by the Playlist Engine for distance/ETA per stop (Chapter 2C),
 * cached briefly in Redis by the caller to avoid redundant calls.
 */
export class GoogleMapsService {
  private get apiKey(): string {
    return loadEnv().GOOGLE_MAPS_API_KEY;
  }

  /**
   * Computes driving distance + duration between an origin and a single
   * destination using the Distance Matrix API.
   */
  async getDrivingDistance(
    origin: LatLng,
    destination: LatLng
  ): Promise<DistanceMatrixResult> {
    const params = new URLSearchParams({
      origins: `${origin.latitude},${origin.longitude}`,
      destinations: `${destination.latitude},${destination.longitude}`,
      mode: "driving",
      key: this.apiKey,
    });

    const response = await fetch(
      `https://maps.googleapis.com/maps/api/distancematrix/json?${params.toString()}`
    );

    if (!response.ok) {
      throw new Error(
        `Google Distance Matrix API request failed: ${response.status}`
      );
    }

    const data = (await response.json()) as {
      status: string;
      rows?: Array<{
        elements?: Array<{
          status: string;
          distance?: { value: number };
          duration?: { value: number };
        }>;
      }>;
    };

    if (data.status !== "OK") {
      throw new Error(`Google Distance Matrix API returned status: ${data.status}`);
    }

    const element = data.rows?.[0]?.elements?.[0];
    if (!element || element.status !== "OK" || !element.distance || !element.duration) {
      throw new Error("Google Distance Matrix API: no route found between points");
    }

    return {
      distanceMeters: element.distance.value,
      durationSeconds: element.duration.value,
    };
  }

  /** Builds a navigable Google Maps URL for a given coordinate. */
  buildGoogleMapsLink(point: LatLng): string {
    return `https://www.google.com/maps/search/?api=1&query=${point.latitude},${point.longitude}`;
  }
}
