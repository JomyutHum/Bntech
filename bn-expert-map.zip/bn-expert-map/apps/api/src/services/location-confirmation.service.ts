import type { PrismaClient } from "@prisma/client";
import { CoordinateRepository } from "../repositories/coordinate.repository.js";
import { AwaitingLocationRequestRepository } from "../repositories/awaiting-location-request.repository.js";
import { AuditLogRepository } from "../repositories/audit-log.repository.js";
import {
  LocationLinkResolverService,
  type LinkResolutionResult,
} from "./location-link-resolver.service.js";
import { ProximityVerificationService } from "./proximity-verification.service.js";
import type { LatLng } from "../utils/geo.js";
import { buildNormalizedAddressKey } from "../utils/address-normalizer.js";
import type {
  LocationSubmissionChannel,
  LocationSubmissionResult,
} from "@bn-expert-map/shared";

export interface FulfillLocationRequestParams {
  awaitingLocationRequestId: string;
  /**
   * Either a pre-resolved coordinate (LINE Location share — the channel is
   * then always LINE_LOCATION), OR raw pasted link text (a map link — the
   * exact channel, e.g. GOOGLE_MAPS_LINK vs APPLE_MAPS_LINK vs WAZE_LINK,
   * is derived internally from the resolved provider, not supplied by the
   * caller, so callers never need to pre-guess which provider a pasted
   * link belongs to).
   */
  candidateCoordinate?: LatLng;
  rawLinkText?: string;
  driverLiveGps: LatLng | null;
}

export type FulfillLocationRequestOutcome =
  | {
      result: "ACCEPTED";
      coordinateId: string;
      distanceMeters: number;
    }
  | {
      result: "REJECTED_TOO_FAR";
      distanceMeters: number;
    }
  | {
      result: "REJECTED_UNRESOLVABLE_LINK";
    };

/**
 * LocationConfirmationService — orchestrates Chapter 4A end-to-end:
 * resolve the candidate coordinate (if a link), run the proximity check,
 * and either persist a new VERIFIED Coordinate or reject + log the
 * attempt. This is the single place where AwaitingLocationRequest
 * fulfillment happens, so the LINE bot route and any future channel
 * (e.g. web app submission) share identical logic.
 */
export class LocationConfirmationService {
  private readonly coordinateRepo: CoordinateRepository;
  private readonly awaitingRepo: AwaitingLocationRequestRepository;
  private readonly auditLogRepo: AuditLogRepository;
  private readonly linkResolver: LocationLinkResolverService;
  private readonly proximityService: ProximityVerificationService;

  constructor(private readonly prisma: PrismaClient) {
    this.coordinateRepo = new CoordinateRepository(prisma);
    this.awaitingRepo = new AwaitingLocationRequestRepository(prisma);
    this.auditLogRepo = new AuditLogRepository(prisma);
    this.linkResolver = new LocationLinkResolverService();
    this.proximityService = new ProximityVerificationService();
  }

  async fulfill(
    params: FulfillLocationRequestParams
  ): Promise<FulfillLocationRequestOutcome> {
    const awaitingRequest = await this.awaitingRepo.findById(
      params.awaitingLocationRequestId
    );
    if (!awaitingRequest) {
      throw new Error(
        `AwaitingLocationRequest ${params.awaitingLocationRequestId} not found`
      );
    }

    // Step 1: resolve the candidate coordinate AND determine the precise
    // channel. If candidateCoordinate is pre-supplied, this is a LINE
    // Location share. Otherwise, resolve the pasted link and derive the
    // channel from whichever provider it matched.
    let candidate: LatLng | null = params.candidateCoordinate ?? null;
    let channel: LocationSubmissionChannel = "LINE_LOCATION";

    if (!candidate && params.rawLinkText) {
      const resolution: LinkResolutionResult = await this.linkResolver.resolveLink(
        params.rawLinkText
      );
      candidate = resolution.coordinate;
      channel = mapProviderToChannel(resolution.provider);
    }

    if (!candidate) {
      await this.awaitingRepo.recordAttempt({
        awaitingLocationRequest: { connect: { id: awaitingRequest.id } },
        submittedVia: channel,
        rawInput: params.rawLinkText ?? "(line_location_payload)",
        result: "REJECTED_UNRESOLVABLE_LINK" satisfies LocationSubmissionResult,
      });
      return { result: "REJECTED_UNRESOLVABLE_LINK" };
    }

    // Step 2: proximity check against the driver's live GPS reading.
    // Note: verify() throws MissingLiveGpsReadingError if driverLiveGps is
    // null — intentionally NOT caught here. The caller (LINE bot handler)
    // must catch this and prompt the driver to share their live location
    // rather than this service silently treating it as any kind of pass.
    const proximityOutcome = this.proximityService.verify(
      candidate,
      params.driverLiveGps
    );

    if (proximityOutcome.outcome === "REJECTED_TOO_FAR") {
      await this.awaitingRepo.recordAttempt({
        awaitingLocationRequest: { connect: { id: awaitingRequest.id } },
        submittedVia: channel,
        rawInput: params.rawLinkText ?? "(line_location_payload)",
        resolvedLatitude: candidate.latitude,
        resolvedLongitude: candidate.longitude,
        driverLiveLatitude: params.driverLiveGps?.latitude,
        driverLiveLongitude: params.driverLiveGps?.longitude,
        distanceMeters: proximityOutcome.distanceMeters,
        result: "REJECTED_TOO_FAR" satisfies LocationSubmissionResult,
      });
      return {
        result: "REJECTED_TOO_FAR",
        distanceMeters: proximityOutcome.distanceMeters,
      };
    }

    // Step 3: ACCEPTED — persist a new verified Coordinate.
    const normalizedAddressKey = awaitingRequest.normalizedAddressKeyDraft;
    const verificationSource =
      channel === "LINE_LOCATION" ? "LINE_LOCATION" : "MAP_LINK";

    const coordinate = await this.coordinateRepo.create({
      latitude: candidate.latitude,
      longitude: candidate.longitude,
      normalizedAddressKey,
      verificationSource,
      verifiedByDriver: { connect: { id: awaitingRequest.driverId } },
    });

    await this.coordinateRepo.recordHistory({
      coordinateId: coordinate.id,
      actorType: "DRIVER",
      actorId: awaitingRequest.driverId,
      action: "VERIFIED",
      diffJson: { source: verificationSource },
    });

    await this.auditLogRepo.record({
      actorType: "DRIVER",
      actorId: awaitingRequest.driverId,
      entityType: "Coordinate",
      entityId: coordinate.id,
      action: "CREATED_VIA_LOCATION_CONFIRMATION",
      diffJson: { verificationSource, distanceMeters: proximityOutcome.distanceMeters },
    });

    await this.awaitingRepo.recordAttempt({
      awaitingLocationRequest: { connect: { id: awaitingRequest.id } },
      submittedVia: channel,
      rawInput: params.rawLinkText ?? "(line_location_payload)",
      resolvedLatitude: candidate.latitude,
      resolvedLongitude: candidate.longitude,
      driverLiveLatitude: params.driverLiveGps?.latitude,
      driverLiveLongitude: params.driverLiveGps?.longitude,
      distanceMeters: proximityOutcome.distanceMeters,
      result: "ACCEPTED" satisfies LocationSubmissionResult,
    });

    await this.awaitingRepo.markFulfilled(awaitingRequest.id);

    return {
      result: "ACCEPTED",
      coordinateId: coordinate.id,
      distanceMeters: proximityOutcome.distanceMeters,
    };
  }

  /** Helper exposed for routes that need to (re)build the draft key. */
  buildDraftKey(fields: Parameters<typeof buildNormalizedAddressKey>[0]): string {
    return buildNormalizedAddressKey(fields);
  }
}

/**
 * Maps LocationLinkResolverService's MapLinkProvider (GOOGLE_SHORT /
 * GOOGLE_FULL / APPLE_MAPS / WAZE / UNKNOWN) to the Prisma-schema-facing
 * LocationSubmissionChannel enum (GOOGLE_MAPS_LINK / APPLE_MAPS_LINK /
 * WAZE_LINK / LINE_LOCATION). These two enums exist for different
 * purposes — the resolver's is about HOW to parse a link, the schema's is
 * about WHAT to record — so they are intentionally not the same enum, but
 * must be kept in sync here whenever either one changes.
 */
function mapProviderToChannel(
  provider: "GOOGLE_SHORT" | "GOOGLE_FULL" | "APPLE_MAPS" | "WAZE" | "UNKNOWN"
): LocationSubmissionChannel {
  switch (provider) {
    case "GOOGLE_SHORT":
    case "GOOGLE_FULL":
      return "GOOGLE_MAPS_LINK";
    case "APPLE_MAPS":
      return "APPLE_MAPS_LINK";
    case "WAZE":
      return "WAZE_LINK";
    case "UNKNOWN":
    default:
      // No real channel applies (link was unresolvable) — default to a
      // value that still satisfies the type; the REJECTED_UNRESOLVABLE_LINK
      // path is what actually gets recorded in this case regardless.
      return "GOOGLE_MAPS_LINK";
  }
}
