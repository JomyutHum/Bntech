import type { PrismaClient } from "@prisma/client";
import { OcrService } from "./ocr.service.js";
import { StorageService } from "./storage.service.js";
import { CoordinateMatchingService } from "./coordinate-matching.service.js";
import { OcrJobRepository } from "../repositories/ocr-job.repository.js";
import { AwaitingLocationRequestRepository } from "../repositories/awaiting-location-request.repository.js";
import {
  parseRawAddressText,
  buildNormalizedAddressKey,
} from "../utils/address-normalizer.js";
import type { LatLng } from "../utils/geo.js";

export type OcrPipelineOutcome =
  | { outcome: "MATCHED"; coordinateId: string; ocrJobId: string }
  | {
      outcome: "POSSIBLE_DUPLICATE";
      candidateCoordinateIds: string[];
      ocrJobId: string;
    }
  | {
      outcome: "AWAITING_LOCATION";
      awaitingLocationRequestId: string;
      ocrJobId: string;
    }
  | { outcome: "FAILED"; reason: string; ocrJobId: string };

/**
 * OcrPipelineService — Build Order step 6.
 *
 * Flow: image -> Google Vision OCR -> AddressNormalizer -> persist OcrJob
 * -> CoordinateMatchingService -> either return a match, surface possible
 * duplicates, or open an AwaitingLocationRequest. NEVER derives a
 * coordinate from OCR text directly (Chapter 1 core principle).
 */
export class OcrPipelineService {
  private readonly ocrService: OcrService;
  private readonly storageService: StorageService;
  private readonly matchingService: CoordinateMatchingService;
  private readonly ocrJobRepo: OcrJobRepository;
  private readonly awaitingRepo: AwaitingLocationRequestRepository;

  constructor(private readonly prisma: PrismaClient) {
    this.ocrService = new OcrService();
    this.storageService = new StorageService();
    this.matchingService = new CoordinateMatchingService(prisma);
    this.ocrJobRepo = new OcrJobRepository(prisma);
    this.awaitingRepo = new AwaitingLocationRequestRepository(prisma);
  }

  async process(params: {
    driverId: string;
    sourceLineMessageId: string;
    imageBuffer: Buffer;
    imageContentType: string;
    imageFileExtension: string;
    driverGpsHint?: LatLng | null;
  }): Promise<OcrPipelineOutcome> {
    // Idempotency: LINE delivers webhooks at-least-once. If we've already
    // processed this exact message, return the existing job's outcome
    // rather than reprocessing (and re-uploading) the same image.
    const existingJob = await this.ocrJobRepo.findBySourceLineMessageId(
      params.sourceLineMessageId
    );
    if (existingJob) {
      return this.outcomeFromExistingJob(existingJob.id);
    }

    const { storagePath } = await this.storageService.uploadParcelImage({
      driverId: params.driverId,
      buffer: params.imageBuffer,
      contentType: params.imageContentType,
      fileExtension: params.imageFileExtension,
    });

    let extraction;
    try {
      extraction = await this.ocrService.extractText(params.imageBuffer);
    } catch (error) {
      const job = await this.ocrJobRepo.create({
        sourceLineMessageId: params.sourceLineMessageId,
        driver: { connect: { id: params.driverId } },
        imageStorageUrl: storagePath,
        status: "FAILED",
        errorMessage: error instanceof Error ? error.message : "OCR failed",
      });
      return {
        outcome: "FAILED",
        reason: "OCR_EXTRACTION_FAILED",
        ocrJobId: job.id,
      };
    }

    const addressFields = parseRawAddressText(extraction.rawText);
    const normalizedAddressKey = buildNormalizedAddressKey(addressFields);

    const job = await this.ocrJobRepo.create({
      sourceLineMessageId: params.sourceLineMessageId,
      driver: { connect: { id: params.driverId } },
      imageStorageUrl: storagePath,
      rawExtractedText: extraction.rawText,
      normalizedAddressKey: normalizedAddressKey || null,
      confidenceScore: extraction.confidenceScore,
      status: "PENDING",
    });

    if (!normalizedAddressKey) {
      // No usable address text extracted at all — log for Admin review,
      // never silently discard (Chapter 2D).
      await this.ocrJobRepo.update(job.id, {
        status: "FAILED",
        errorMessage: "No address fields could be extracted from OCR text",
      });
      return {
        outcome: "FAILED",
        reason: "NO_ADDRESS_TEXT_EXTRACTED",
        ocrJobId: job.id,
      };
    }

    const matchResult = await this.matchingService.findMatch(
      addressFields,
      params.driverGpsHint
    );

    if (matchResult.type === "EXACT_MATCH" && matchResult.exactMatch) {
      await this.ocrJobRepo.update(job.id, {
        status: "PROCESSED",
        matchedCoordinate: { connect: { id: matchResult.exactMatch.id } },
      });
      return {
        outcome: "MATCHED",
        coordinateId: matchResult.exactMatch.id,
        ocrJobId: job.id,
      };
    }

    if (matchResult.type === "POSSIBLE_DUPLICATE" && matchResult.candidates) {
      await this.ocrJobRepo.update(job.id, { status: "NO_MATCH" });
      return {
        outcome: "POSSIBLE_DUPLICATE",
        candidateCoordinateIds: matchResult.candidates.map(
          (c) => c.coordinate.id
        ),
        ocrJobId: job.id,
      };
    }

    // NO_MATCH -> open an AwaitingLocationRequest (Chapter 4A entry point).
    await this.ocrJobRepo.update(job.id, { status: "AWAITING_LOCATION" });

    const awaitingRequest = await this.awaitingRepo.create({
      driver: { connect: { id: params.driverId } },
      ocrJob: { connect: { id: job.id } },
      normalizedAddressKeyDraft: normalizedAddressKey,
      rawAddressText: extraction.rawText,
      status: "WAITING",
    });

    return {
      outcome: "AWAITING_LOCATION",
      awaitingLocationRequestId: awaitingRequest.id,
      ocrJobId: job.id,
    };
  }

  private async outcomeFromExistingJob(
    ocrJobId: string
  ): Promise<OcrPipelineOutcome> {
    const job = await this.ocrJobRepo.findById(ocrJobId);
    if (!job) {
      return { outcome: "FAILED", reason: "JOB_NOT_FOUND", ocrJobId };
    }
    if (job.status === "PROCESSED" && job.matchedCoordinateId) {
      return {
        outcome: "MATCHED",
        coordinateId: job.matchedCoordinateId,
        ocrJobId: job.id,
      };
    }
    if (job.status === "AWAITING_LOCATION") {
      const awaiting = await this.awaitingRepo.findActiveByDriverId(
        job.driverId
      );
      if (awaiting) {
        return {
          outcome: "AWAITING_LOCATION",
          awaitingLocationRequestId: awaiting.id,
          ocrJobId: job.id,
        };
      }
    }
    return {
      outcome: "FAILED",
      reason: job.errorMessage ?? "DUPLICATE_WEBHOOK_DELIVERY",
      ocrJobId: job.id,
    };
  }
}
