// REQUIRES_VERIFICATION: this import shape (`ImageAnnotatorClient` from
// @google-cloud/vision v4.x, and the `documentTextDetection` method
// signature below) was written from memory without network access to
// confirm against the published package. Verify against the installed
// package's TypeScript types after `npm install` before relying on this
// in production.
import { ImageAnnotatorClient } from "@google-cloud/vision";
import { loadEnv } from "../config/env.js";

/**
 * OcrService — Google Vision integration (Chapter 2D / Chapter 1).
 *
 * CRITICAL RULE: this service extracts TEXT ONLY. It must never attempt to
 * derive or return a coordinate from OCR text. Any geocoding-like behavior
 * belongs nowhere in this file.
 */

export interface OcrExtractionResult {
  rawText: string;
  confidenceScore: number | null;
}

export class OcrService {
  private client: ImageAnnotatorClient | null = null;

  private getClient(): ImageAnnotatorClient {
    if (this.client) return this.client;

    const env = loadEnv();
    let credentials: Record<string, unknown>;
    try {
      credentials = JSON.parse(env.GOOGLE_APPLICATION_CREDENTIALS_JSON);
    } catch {
      throw new Error(
        "GOOGLE_APPLICATION_CREDENTIALS_JSON is not valid JSON. " +
          "Paste the full contents of the downloaded service account key file."
      );
    }

    this.client = new ImageAnnotatorClient({ credentials });
    return this.client;
  }

  /**
   * Runs DOCUMENT_TEXT_DETECTION (better for dense label text than plain
   * TEXT_DETECTION) on the given image buffer and returns the raw
   * extracted text plus a confidence score.
   */
  async extractText(imageBuffer: Buffer): Promise<OcrExtractionResult> {
    const client = this.getClient();

    const [result] = await client.documentTextDetection({
      image: { content: imageBuffer },
    });

    const fullText = result.fullTextAnnotation?.text ?? "";

    // Average page-level confidence across detected pages, if available.
    const pages = result.fullTextAnnotation?.pages ?? [];
    const confidences = pages
      .map((page) => page.confidence)
      .filter((c): c is number => typeof c === "number");
    const confidenceScore =
      confidences.length > 0
        ? confidences.reduce((sum, c) => sum + c, 0) / confidences.length
        : null;

    return { rawText: fullText, confidenceScore };
  }
}
