import crypto from "node:crypto";
import { loadEnv } from "../config/env.js";
import { getRedis } from "../config/redis.js";

const WEBHOOK_DEDUP_TTL_SECONDS = 60 * 10; // 10 minutes is plenty for LINE's redelivery window

/**
 * LineWebhookService — signature verification + at-least-once dedup
 * (Chapter 2A).
 */
export class LineWebhookService {
  /**
   * Verifies the LINE webhook signature using the channel secret. LINE
   * signs the raw request body with HMAC-SHA256, base64-encoded, sent in
   * the `x-line-signature` header.
   */
  verifySignature(rawBody: string, signatureHeader: string | undefined): boolean {
    if (!signatureHeader) return false;
    const env = loadEnv();

    const expectedSignature = crypto
      .createHmac("sha256", env.LINE_CHANNEL_SECRET)
      .update(rawBody)
      .digest("base64");

    // Constant-time comparison to avoid timing attacks.
    const a = Buffer.from(expectedSignature);
    const b = Buffer.from(signatureHeader);
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  }

  /**
   * Returns true if this webhook event ID has already been processed
   * (LINE delivers at-least-once, so duplicates are expected and must be
   * ignored rather than double-processed).
   */
  async isDuplicateEvent(eventId: string): Promise<boolean> {
    const redis = getRedis();
    const key = `line:webhook-dedup:${eventId}`;
    // SET ... NX returns null if the key already existed (i.e. duplicate).
    const result = await redis.set(
      key,
      "1",
      "EX",
      WEBHOOK_DEDUP_TTL_SECONDS,
      "NX"
    );
    return result === null;
  }
}
