import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { loadEnv } from "../config/env.js";
import type {
  DriverJwtPayload,
  AdminJwtPayload,
  JwtPayload,
} from "@bn-expert-map/shared";

export class AuthService {
  private get secret(): string {
    return loadEnv().JWT_SECRET;
  }

  private get expiresIn(): string {
    return loadEnv().JWT_EXPIRES_IN;
  }

  issueDriverToken(payload: Omit<DriverJwtPayload, "role">): string {
    const fullPayload: DriverJwtPayload = { ...payload, role: "DRIVER" };
    return jwt.sign(fullPayload, this.secret, { expiresIn: this.expiresIn });
  }

  issueAdminToken(payload: Omit<AdminJwtPayload, "role">): string {
    const fullPayload: AdminJwtPayload = { ...payload, role: "ADMIN" };
    return jwt.sign(fullPayload, this.secret, { expiresIn: this.expiresIn });
  }

  verifyToken(token: string): JwtPayload {
    return jwt.verify(token, this.secret) as JwtPayload;
  }

  async hashPassword(plainPassword: string): Promise<string> {
    const SALT_ROUNDS = 12;
    return bcrypt.hash(plainPassword, SALT_ROUNDS);
  }

  async verifyPassword(
    plainPassword: string,
    passwordHash: string
  ): Promise<boolean> {
    return bcrypt.compare(plainPassword, passwordHash);
  }
}
