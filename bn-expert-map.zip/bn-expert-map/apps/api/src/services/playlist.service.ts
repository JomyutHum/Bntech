import type { PrismaClient } from "@prisma/client";
import { PlaylistRepository, type PlaylistWithStops } from "../repositories/playlist.repository.js";
import { AuditLogRepository } from "../repositories/audit-log.repository.js";
import { GoogleMapsService } from "./google-maps.service.js";
import { haversineDistanceMeters, type LatLng } from "../utils/geo.js";
import { getRedis } from "../config/redis.js";

const DISTANCE_CACHE_TTL_SECONDS = 120;

export class PlaylistService {
  private readonly playlistRepo: PlaylistRepository;
  private readonly auditLogRepo: AuditLogRepository;
  private readonly mapsService: GoogleMapsService;

  constructor(private readonly prisma: PrismaClient) {
    this.playlistRepo = new PlaylistRepository(prisma);
    this.auditLogRepo = new AuditLogRepository(prisma);
    this.mapsService = new GoogleMapsService();
  }

  async getOrCreateTodayPlaylist(driverId: string): Promise<PlaylistWithStops> {
    const today = new Date();
    const existing = await this.playlistRepo.findActiveForDriverOnDate(
      driverId,
      today
    );
    if (existing) return existing;

    await this.playlistRepo.createForDriverOnDate(driverId, today);
    const created = await this.playlistRepo.findActiveForDriverOnDate(
      driverId,
      today
    );
    if (!created) {
      throw new Error("Failed to create today's playlist");
    }
    return created;
  }

  async addStop(params: {
    playlistId: string;
    coordinateId: string;
    actorType: "DRIVER" | "ADMIN";
    actorId: string;
  }): Promise<void> {
    // New stops are appended at the end; nearest-first reordering happens
    // on the next read via reorderByProximity, not on every insert, to
    // avoid an extra round trip per add.
    const currentCount = await this.prisma.playlistStop.count({
      where: { playlistId: params.playlistId, status: "PENDING" },
    });

    await this.playlistRepo.addStop({
      playlistId: params.playlistId,
      coordinateId: params.coordinateId,
      orderIndex: currentCount,
    });

    await this.auditLogRepo.record({
      actorType: params.actorType,
      actorId: params.actorId,
      entityType: "PlaylistStop",
      entityId: params.coordinateId,
      action: "ADDED_TO_PLAYLIST",
    });
  }

  /**
   * Re-ranks PENDING stops nearest-first relative to the driver's current
   * position. Called whenever a stop is marked done/skipped, or when the
   * driver's position has moved meaningfully (per Chapter 2C: "recalculated
   * when a stop is marked done/skipped").
   */
  async reorderByProximity(
    playlistId: string,
    driverCurrentPosition: LatLng
  ): Promise<void> {
    const stops = await this.prisma.playlistStop.findMany({
      where: { playlistId, status: "PENDING" },
      include: { coordinate: true },
    });

    const ranked = stops
      .map((stop) => ({
        stopId: stop.id,
        distance: haversineDistanceMeters(driverCurrentPosition, {
          latitude: stop.coordinate.latitude,
          longitude: stop.coordinate.longitude,
        }),
      }))
      .sort((a, b) => a.distance - b.distance);

    await this.playlistRepo.reorderStops(
      playlistId,
      ranked.map((r) => r.stopId)
    );
  }

  async markStopStatus(params: {
    stopId: string;
    status: "DELIVERED" | "SKIPPED" | "PROBLEM";
    problemNote?: string;
    actorType: "DRIVER" | "ADMIN";
    actorId: string;
    driverCurrentPosition?: LatLng;
  }): Promise<void> {
    const stop = await this.playlistRepo.findStopById(params.stopId);
    if (!stop) {
      throw new Error(`PlaylistStop ${params.stopId} not found`);
    }

    await this.playlistRepo.updateStopStatus({
      stopId: params.stopId,
      status: params.status,
      problemNote: params.problemNote,
    });

    await this.auditLogRepo.record({
      actorType: params.actorType,
      actorId: params.actorId,
      entityType: "PlaylistStop",
      entityId: params.stopId,
      action: `STOP_${params.status}`,
      diffJson: params.problemNote ? { problemNote: params.problemNote } : undefined,
    });

    // Per spec: once DELIVERED or SKIPPED, remove from active view
    // immediately AND re-rank the remaining stops nearest-first.
    if (
      (params.status === "DELIVERED" || params.status === "SKIPPED") &&
      params.driverCurrentPosition
    ) {
      await this.reorderByProximity(stop.playlistId, params.driverCurrentPosition);
    }
  }

  /**
   * Computes (and Redis-caches) distance/ETA for a stop relative to the
   * driver's current position, to avoid redundant Distance Matrix calls
   * when the list is re-rendered without meaningful driver movement.
   */
  async getDistanceEtaForStop(params: {
    stopId: string;
    driverCurrentPosition: LatLng;
    destination: LatLng;
  }): Promise<{ distanceMeters: number; etaMinutes: number }> {
    const redis = getRedis();
    const cacheKey = `playlist:stop-distance:${params.stopId}:${params.driverCurrentPosition.latitude.toFixed(5)},${params.driverCurrentPosition.longitude.toFixed(5)}`;

    const cached = await redis.get(cacheKey);
    if (cached) {
      return JSON.parse(cached) as { distanceMeters: number; etaMinutes: number };
    }

    const result = await this.mapsService.getDrivingDistance(
      params.driverCurrentPosition,
      params.destination
    );

    const payload = {
      distanceMeters: result.distanceMeters,
      etaMinutes: Math.ceil(result.durationSeconds / 60),
    };

    await redis.set(cacheKey, JSON.stringify(payload), "EX", DISTANCE_CACHE_TTL_SECONDS);
    await this.playlistRepo.updateStopDistanceEta({
      stopId: params.stopId,
      distanceMeters: payload.distanceMeters,
      etaMinutes: payload.etaMinutes,
    });

    return payload;
  }
}
