import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import { loadEnv } from "../config/env.js";

/**
 * StorageService — wraps Supabase Storage for persisting uploaded
 * parcel-label/slip images. Uses the SUPABASE_SERVICE_ROLE_KEY server-side
 * so uploads bypass RLS (Chapter 6). Supabase is used for file storage
 * only here — no Auth/Realtime usage.
 */
export class StorageService {
  private readonly client: SupabaseClient;
  private readonly bucket: string;

  constructor() {
    const env = loadEnv();
    this.client = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY, {
      auth: { persistSession: false },
    });
    this.bucket = env.SUPABASE_STORAGE_BUCKET;
  }

  /**
   * Uploads a parcel label/slip image buffer and returns its public-ish
   * storage path (not necessarily publicly readable — bucket should be
   * private; use getSignedUrl for temporary read access).
   */
  async uploadParcelImage(params: {
    driverId: string;
    buffer: Buffer;
    contentType: string;
    fileExtension: string;
  }): Promise<{ storagePath: string }> {
    const timestamp = Date.now();
    const storagePath = `parcel-images/${params.driverId}/${timestamp}.${params.fileExtension}`;

    const { error } = await this.client.storage
      .from(this.bucket)
      .upload(storagePath, params.buffer, {
        contentType: params.contentType,
        upsert: false,
      });

    if (error) {
      throw new Error(`StorageService upload failed: ${error.message}`);
    }

    return { storagePath };
  }

  /**
   * Returns a time-limited signed URL for reading a previously uploaded
   * image (e.g. for Admin OCR-job review UI).
   */
  async getSignedUrl(
    storagePath: string,
    expiresInSeconds = 3600
  ): Promise<string> {
    const { data, error } = await this.client.storage
      .from(this.bucket)
      .createSignedUrl(storagePath, expiresInSeconds);

    if (error || !data) {
      throw new Error(
        `StorageService signed URL failed: ${error?.message ?? "unknown error"}`
      );
    }

    return data.signedUrl;
  }
}
