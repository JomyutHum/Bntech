import type { LatLng } from "../utils/geo.js";

/**
 * LocationLinkResolverService — Chapter 4A.
 *
 * Detects and resolves map links from Google Maps, Apple Maps, and Waze
 * into lat/lng coordinates. Google short links require a server-side
 * redirect resolution (no coordinates embedded in the short URL itself);
 * all other supported link types embed lat/lng directly and are parsed
 * with regex.
 */

export type MapLinkProvider =
  | "GOOGLE_SHORT"
  | "GOOGLE_FULL"
  | "APPLE_MAPS"
  | "WAZE"
  | "UNKNOWN";

export interface LinkResolutionResult {
  provider: MapLinkProvider;
  coordinate: LatLng | null;
}

const GOOGLE_SHORT_LINK_PATTERN = /https?:\/\/maps\.app\.goo\.gl\/[A-Za-z0-9_-]+/;
const GOOGLE_FULL_LINK_PATTERN = /https?:\/\/(www\.)?google\.[a-z.]+\/maps/;
const APPLE_MAPS_PATTERN = /https?:\/\/maps\.apple\.com\//;
const WAZE_PATTERN = /https?:\/\/(www\.)?waze\.com\//;

// Coordinate extraction patterns for links that embed lat/lng directly.
const GOOGLE_AT_LATLNG_PATTERN = /@(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/;
const GOOGLE_QUERY_LATLNG_PATTERN = /[?&]q=(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/;
const APPLE_LL_PATTERN = /[?&]ll=(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/;
const WAZE_LL_PATTERN = /[?&]ll=(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/;
const WAZE_TO_LL_PATTERN = /[?&]to=ll\.(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/;

export interface ShortLinkResolver {
  /**
   * Resolves a Google Maps short link (maps.app.goo.gl/...) to its final
   * redirected URL by following the HTTP redirect chain. Returns null if
   * resolution fails for any reason (network error, no redirect, etc.).
   */
  resolveRedirect(shortUrl: string): Promise<string | null>;
}

/**
 * Default ShortLinkResolver implementation: issues a HEAD request and
 * follows redirects manually (so we can read the final Location header)
 * rather than relying on fetch's automatic redirect-following, since we
 * need the final URL string, not just the final response body.
 */
export class HttpShortLinkResolver implements ShortLinkResolver {
  async resolveRedirect(shortUrl: string): Promise<string | null> {
    try {
      let currentUrl = shortUrl;
      // Follow up to 5 redirects manually.
      for (let i = 0; i < 5; i++) {
        const response = await fetch(currentUrl, {
          method: "GET",
          redirect: "manual",
        });

        const location = response.headers.get("location");
        if (!location) {
          // No further redirect — if this response's URL already contains
          // coordinates, this is our final URL.
          return response.url || currentUrl;
        }
        currentUrl = location.startsWith("http")
          ? location
          : new URL(location, currentUrl).toString();
      }
      return currentUrl;
    } catch {
      return null;
    }
  }
}

export class LocationLinkResolverService {
  constructor(
    private readonly shortLinkResolver: ShortLinkResolver = new HttpShortLinkResolver()
  ) {}

  detectProvider(text: string): MapLinkProvider {
    if (GOOGLE_SHORT_LINK_PATTERN.test(text)) return "GOOGLE_SHORT";
    if (GOOGLE_FULL_LINK_PATTERN.test(text)) return "GOOGLE_FULL";
    if (APPLE_MAPS_PATTERN.test(text)) return "APPLE_MAPS";
    if (WAZE_PATTERN.test(text)) return "WAZE";
    return "UNKNOWN";
  }

  /**
   * Attempts to resolve a pasted map link (any supported provider) into a
   * lat/lng coordinate. Returns coordinate: null when detection/parsing
   * fails — callers MUST treat this as REJECTED_UNRESOLVABLE_LINK, never
   * fall back to guessing.
   */
  async resolveLink(text: string): Promise<LinkResolutionResult> {
    const provider = this.detectProvider(text);

    switch (provider) {
      case "GOOGLE_SHORT":
        return this.resolveGoogleShortLink(text);
      case "GOOGLE_FULL":
        return {
          provider,
          coordinate: this.extractGoogleFullLinkCoordinate(text),
        };
      case "APPLE_MAPS":
        return { provider, coordinate: this.extractAppleMapsCoordinate(text) };
      case "WAZE":
        return { provider, coordinate: this.extractWazeCoordinate(text) };
      case "UNKNOWN":
      default:
        return { provider: "UNKNOWN", coordinate: null };
    }
  }

  /**
   * Safely URL-decodes a string for regex matching purposes. Some
   * providers (notably Waze) URL-encode the comma between lat/lng as
   * %2C. Falls back to the original string if decoding fails.
   */
  private safeDecode(text: string): string {
    try {
      return decodeURIComponent(text);
    } catch {
      return text;
    }
  }

  private async resolveGoogleShortLink(
    text: string
  ): Promise<LinkResolutionResult> {
    const match = text.match(GOOGLE_SHORT_LINK_PATTERN);
    if (!match) return { provider: "GOOGLE_SHORT", coordinate: null };

    const resolvedUrl = await this.shortLinkResolver.resolveRedirect(
      match[0]
    );
    if (!resolvedUrl) {
      return { provider: "GOOGLE_SHORT", coordinate: null };
    }

    const coordinate = this.extractGoogleFullLinkCoordinate(resolvedUrl);
    return { provider: "GOOGLE_SHORT", coordinate };
  }

  private extractGoogleFullLinkCoordinate(text: string): LatLng | null {
    const decoded = this.safeDecode(text);
    const atMatch = decoded.match(GOOGLE_AT_LATLNG_PATTERN);
    if (atMatch) {
      return {
        latitude: parseFloat(atMatch[1]),
        longitude: parseFloat(atMatch[2]),
      };
    }
    const queryMatch = decoded.match(GOOGLE_QUERY_LATLNG_PATTERN);
    if (queryMatch) {
      return {
        latitude: parseFloat(queryMatch[1]),
        longitude: parseFloat(queryMatch[2]),
      };
    }
    return null;
  }

  private extractAppleMapsCoordinate(text: string): LatLng | null {
    const decoded = this.safeDecode(text);
    const match = decoded.match(APPLE_LL_PATTERN);
    if (!match) return null;
    return { latitude: parseFloat(match[1]), longitude: parseFloat(match[2]) };
  }

  private extractWazeCoordinate(text: string): LatLng | null {
    const decoded = this.safeDecode(text);
    const llMatch = decoded.match(WAZE_LL_PATTERN);
    if (llMatch) {
      return {
        latitude: parseFloat(llMatch[1]),
        longitude: parseFloat(llMatch[2]),
      };
    }
    const toMatch = decoded.match(WAZE_TO_LL_PATTERN);
    if (toMatch) {
      return {
        latitude: parseFloat(toMatch[1]),
        longitude: parseFloat(toMatch[2]),
      };
    }
    return null;
  }
}
