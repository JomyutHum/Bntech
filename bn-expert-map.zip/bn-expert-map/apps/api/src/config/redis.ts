import Redis from "ioredis";
import { loadEnv } from "./env.js";

let redisClient: Redis | null = null;

export function getRedis(): Redis {
  if (redisClient) return redisClient;
  const env = loadEnv();
  redisClient = new Redis(env.REDIS_URL, {
    maxRetriesPerRequest: 3,
  });
  return redisClient;
}
