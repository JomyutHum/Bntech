import { PrismaClient } from "@prisma/client";

/**
 * Singleton Prisma client. In development, reuse the client across hot
 * reloads via a global to avoid exhausting the connection pool.
 */
declare global {
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

export const prisma: PrismaClient =
  global.__prisma ??
  new PrismaClient({
    log:
      process.env.NODE_ENV === "development"
        ? ["warn", "error"]
        : ["error"],
  });

if (process.env.NODE_ENV === "development") {
  global.__prisma = prisma;
}
