import { z } from "zod";

/**
 * Centralized, validated environment configuration. Fails fast at startup
 * with a clear error message if a required variable is missing, rather
 * than failing confusingly deep inside a service at request time.
 */

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  PORT: z.coerce.number().int().positive().default(4000),

  DATABASE_URL: z.string().min(1, "DATABASE_URL is required"),
  DIRECT_URL: z.string().min(1, "DIRECT_URL is required"),

  REDIS_URL: z.string().min(1, "REDIS_URL is required"),

  JWT_SECRET: z.string().min(32, "JWT_SECRET must be at least 32 characters"),
  JWT_EXPIRES_IN: z.string().default("7d"),

  LINE_CHANNEL_SECRET: z.string().min(1, "LINE_CHANNEL_SECRET is required"),
  LINE_CHANNEL_ACCESS_TOKEN: z
    .string()
    .min(1, "LINE_CHANNEL_ACCESS_TOKEN is required"),
  LINE_LOGIN_CHANNEL_ID: z.string().min(1, "LINE_LOGIN_CHANNEL_ID is required"),
  LINE_LOGIN_CHANNEL_SECRET: z
    .string()
    .min(1, "LINE_LOGIN_CHANNEL_SECRET is required"),

  GOOGLE_APPLICATION_CREDENTIALS_JSON: z
    .string()
    .min(1, "GOOGLE_APPLICATION_CREDENTIALS_JSON is required"),
  GOOGLE_MAPS_API_KEY: z.string().min(1, "GOOGLE_MAPS_API_KEY is required"),

  SUPABASE_URL: z.string().url("SUPABASE_URL must be a valid URL"),
  SUPABASE_PUBLISHABLE_KEY: z
    .string()
    .min(1, "SUPABASE_PUBLISHABLE_KEY is required"),
  SUPABASE_SERVICE_ROLE_KEY: z
    .string()
    .min(1, "SUPABASE_SERVICE_ROLE_KEY is required"),
  SUPABASE_STORAGE_BUCKET: z
    .string()
    .min(1, "SUPABASE_STORAGE_BUCKET is required"),
});

export type Env = z.infer<typeof envSchema>;

let cachedEnv: Env | null = null;

/**
 * Parses and validates process.env. Throws with a readable, aggregated
 * error message listing every missing/invalid variable if validation
 * fails — intentionally loud and early rather than allowing partial
 * startup with undefined secrets.
 */
export function loadEnv(): Env {
  if (cachedEnv) return cachedEnv;

  const result = envSchema.safeParse(process.env);
  if (!result.success) {
    const issues = result.error.issues
      .map((issue) => `  - ${issue.path.join(".")}: ${issue.message}`)
      .join("\n");
    throw new Error(
      `Invalid/missing environment variables:\n${issues}\n\n` +
        "See .env.example for where to obtain each value."
    );
  }

  cachedEnv = result.data;
  return cachedEnv;
}

/** For tests only — allows resetting the cache between test runs. */
export function _resetEnvCacheForTests(): void {
  cachedEnv = null;
}
