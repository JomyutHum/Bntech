import type { FastifyInstance } from "fastify";
import fastifyRateLimit from "@fastify/rate-limit";
import { getRedis } from "../config/redis.js";

/**
 * Registers Redis-backed rate limiting on the Fastify instance.
 * Chapter 2.3: "LINE webhook endpoint and all public API routes are
 * rate-limited (Redis-backed) to prevent abuse."
 *
 * Note: @fastify/rate-limit's `redis` option accepting a raw ioredis
 * instance is a long-stable, documented pattern — lower risk than the
 * LINE/Vision SDK shapes flagged elsewhere, but still worth a quick check
 * against the installed version's types if rate limiting misbehaves.
 */
export async function registerRateLimit(app: FastifyInstance): Promise<void> {
  await app.register(fastifyRateLimit, {
    max: 100,
    timeWindow: "1 minute",
    redis: getRedis(),
    // Use a stable key per-driver/admin when authenticated, falling back
    // to IP for unauthenticated routes (e.g. the LINE webhook itself,
    // which is rate-limited per-source-IP since LINE doesn't auth via JWT).
    keyGenerator: (request) => {
      const authHeader = request.headers.authorization;
      if (authHeader) return authHeader;
      return request.ip;
    },
  });
}

/** Stricter rate limit config specifically for the LINE webhook route. */
export const lineWebhookRateLimitConfig = {
  rateLimit: {
    max: 60,
    timeWindow: "1 minute",
  },
};
