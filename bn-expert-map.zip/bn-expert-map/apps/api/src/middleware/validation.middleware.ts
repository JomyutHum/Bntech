import type { FastifyRequest, FastifyReply } from "fastify";
import type { ZodSchema } from "zod";

/**
 * Returns a Fastify preHandler that validates request.body against the
 * given Zod schema. Replaces request.body with the parsed (and
 * default-filled) value on success; sends 400 with a clear error shape on
 * failure. Per Chapter 5: every API input is validated at the route
 * boundary before reaching service logic.
 */
export function validateBody<T>(schema: ZodSchema<T>) {
  return async (request: FastifyRequest, reply: FastifyReply): Promise<void> => {
    const result = schema.safeParse(request.body);
    if (!result.success) {
      await reply.code(400).send({
        success: false,
        error: {
          code: "VALIDATION_ERROR",
          message: result.error.issues
            .map((i) => `${i.path.join(".")}: ${i.message}`)
            .join("; "),
        },
      });
      return;
    }
    request.body = result.data;
  };
}

/**
 * Returns a Fastify preHandler that validates request.query against the
 * given Zod schema, replacing it with the parsed/coerced value.
 */
export function validateQuery<T>(schema: ZodSchema<T>) {
  return async (request: FastifyRequest, reply: FastifyReply): Promise<void> => {
    const result = schema.safeParse(request.query);
    if (!result.success) {
      await reply.code(400).send({
        success: false,
        error: {
          code: "VALIDATION_ERROR",
          message: result.error.issues
            .map((i) => `${i.path.join(".")}: ${i.message}`)
            .join("; "),
        },
      });
      return;
    }
    request.query = result.data as typeof request.query;
  };
}
