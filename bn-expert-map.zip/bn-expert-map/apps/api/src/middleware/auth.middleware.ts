import type { FastifyRequest, FastifyReply } from "fastify";
import { AuthService } from "../services/auth.service.js";
import {
  isDriverPayload,
  isAdminPayload,
  type JwtPayload,
} from "@bn-expert-map/shared";

declare module "fastify" {
  interface FastifyRequest {
    authUser?: JwtPayload;
  }
}

const authService = new AuthService();

function extractBearerToken(request: FastifyRequest): string | null {
  const header = request.headers.authorization;
  if (!header || !header.startsWith("Bearer ")) return null;
  return header.slice("Bearer ".length).trim();
}

/**
 * Verifies the JWT on the request and attaches the decoded payload to
 * request.authUser. Sends 401 if missing/invalid. Use as a Fastify
 * preHandler hook.
 */
export async function requireAuth(
  request: FastifyRequest,
  reply: FastifyReply
): Promise<void> {
  const token = extractBearerToken(request);
  if (!token) {
    await reply.code(401).send({
      success: false,
      error: { code: "UNAUTHORIZED", message: "Missing bearer token" },
    });
    return;
  }

  try {
    const payload = authService.verifyToken(token);
    request.authUser = payload;
  } catch {
    await reply.code(401).send({
      success: false,
      error: { code: "UNAUTHORIZED", message: "Invalid or expired token" },
    });
  }
}

/** Use after requireAuth to additionally restrict the route to ADMIN role. */
export async function requireAdmin(
  request: FastifyRequest,
  reply: FastifyReply
): Promise<void> {
  if (!request.authUser || !isAdminPayload(request.authUser)) {
    await reply.code(403).send({
      success: false,
      error: { code: "FORBIDDEN", message: "Admin role required" },
    });
  }
}

/** Use after requireAuth to additionally restrict the route to DRIVER role. */
export async function requireDriver(
  request: FastifyRequest,
  reply: FastifyReply
): Promise<void> {
  if (!request.authUser || !isDriverPayload(request.authUser)) {
    await reply.code(403).send({
      success: false,
      error: { code: "FORBIDDEN", message: "Driver role required" },
    });
  }
}
