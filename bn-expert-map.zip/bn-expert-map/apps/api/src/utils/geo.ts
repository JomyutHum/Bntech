/**
 * Geo utilities — haversine great-circle distance, shared by
 * CoordinateMatchingService (Chapter 4) and ProximityVerificationService
 * (Chapter 4A).
 */

const EARTH_RADIUS_METERS = 6371000;

export interface LatLng {
  latitude: number;
  longitude: number;
}

function toRadians(degrees: number): number {
  return (degrees * Math.PI) / 180;
}

/**
 * Computes the great-circle distance between two lat/lng points in meters
 * using the haversine formula.
 */
export function haversineDistanceMeters(a: LatLng, b: LatLng): number {
  const dLat = toRadians(b.latitude - a.latitude);
  const dLng = toRadians(b.longitude - a.longitude);

  const lat1 = toRadians(a.latitude);
  const lat2 = toRadians(b.latitude);

  const sinDLat = Math.sin(dLat / 2);
  const sinDLng = Math.sin(dLng / 2);

  const h =
    sinDLat * sinDLat +
    Math.cos(lat1) * Math.cos(lat2) * sinDLng * sinDLng;

  const c = 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));

  return EARTH_RADIUS_METERS * c;
}

export function isWithinRadiusMeters(
  a: LatLng,
  b: LatLng,
  radiusMeters: number
): boolean {
  return haversineDistanceMeters(a, b) <= radiusMeters;
}
