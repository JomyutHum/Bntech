/**
 * AddressNormalizer — standardizes raw Thai address text/fields into a
 * deterministic lookup key used by CoordinateMatchingService.
 *
 * Spec reference: Chapter 4, point 1 (PRIMARY match key).
 */

export interface AddressFields {
  houseNumber?: string | null;
  moo?: string | null;
  soi?: string | null;
  road?: string | null;
  subdistrict?: string | null;
  district?: string | null;
  province?: string | null;
}

// Common Thai address abbreviations expanded to their full form before
// building the key, so "ถ." and "ถนน" hash to the same key.
const ABBREVIATION_MAP: Record<string, string> = {
  "ถ.": "ถนน",
  "ต.": "ตำบล",
  "อ.": "อำเภอ",
  "จ.": "จังหวัด",
  "ม.": "หมู่",
  "ซ.": "ซอย",
  "ต": "ตำบล",
  "ขต.": "เขต", // Bangkok-style "เขต" sometimes abbreviated
};

function expandAbbreviations(text: string): string {
  let result = text;
  for (const [abbr, full] of Object.entries(ABBREVIATION_MAP)) {
    // Replace only when it appears as a standalone token-ish prefix.
    result = result.split(abbr).join(full);
  }
  return result;
}

function normalizeWhitespace(text: string): string {
  return text.replace(/\s+/g, " ").trim();
}

function normalizeField(value: string | null | undefined): string {
  if (!value) return "";
  const expanded = expandAbbreviations(value);
  const collapsed = normalizeWhitespace(expanded);
  return collapsed.toLowerCase();
}

/**
 * Builds the deterministic normalizedAddressKey from address components.
 * Order matters and must stay consistent: soi + road + moo + houseNumber +
 * subdistrict + district + province (per Chapter 3 schema comment).
 */
export function buildNormalizedAddressKey(fields: AddressFields): string {
  const parts = [
    normalizeField(fields.soi),
    normalizeField(fields.road),
    normalizeField(fields.moo),
    normalizeField(fields.houseNumber),
    normalizeField(fields.subdistrict),
    normalizeField(fields.district),
    normalizeField(fields.province),
  ];
  return parts.filter((p) => p.length > 0).join("|");
}

/**
 * Computes a simple fuzzy-similarity score between two normalized address
 * keys, used for the SECONDARY (fuzzy) matching tier in
 * CoordinateMatchingService. Returns a value between 0 (no similarity) and
 * 1 (identical).
 *
 * Implementation: token-overlap (Jaccard-like) over the pipe-delimited
 * parts, which tolerates minor formatting differences (e.g. extra spaces,
 * already-normalized abbreviations) without being a heavyweight NLP
 * dependency. This is intentionally conservative — it is a SUPPORTING
 * signal only (see Chapter 4, point 2/3), never a sole deciding factor.
 */
export function fuzzyAddressSimilarity(keyA: string, keyB: string): number {
  if (!keyA || !keyB) return 0;
  const partsA = new Set(keyA.split("|").filter(Boolean));
  const partsB = new Set(keyB.split("|").filter(Boolean));
  if (partsA.size === 0 || partsB.size === 0) return 0;

  let intersectionSize = 0;
  for (const part of partsA) {
    if (partsB.has(part)) intersectionSize += 1;
  }
  const unionSize = new Set([...partsA, ...partsB]).size;
  if (unionSize === 0) return 0;
  return intersectionSize / unionSize;
}

/**
 * Raw OCR text -> best-effort structured AddressFields extraction.
 *
 * NOTE: this is a best-effort regex/heuristic parser for common Thai
 * address patterns appearing on parcel labels. It NEVER invents a
 * coordinate — it only extracts text fields. Low-confidence/unparseable
 * fields are left undefined rather than guessed, per the "never guess"
 * principle (Chapter 1).
 */
export function parseRawAddressText(rawText: string): AddressFields {
  const text = normalizeWhitespace(rawText);

  const houseNumberMatch = text.match(/(?:บ้านเลขที่|เลขที่)\s*([0-9/.-]+)/);
  const mooMatch = text.match(/(?:หมู่ที่|หมู่|ม\.)\s*([0-9]+)/);
  // Capture a single token plus an optional trailing number (e.g. "พระราม 2",
  // "สุขุมวิท 71") — deliberately NOT a second word, since allowing any
  // second word causes the next field's keyword (e.g. "ถนน", "ตำบล") to be
  // swallowed into this capture when it immediately follows.
  const soiMatch = text.match(/(?:ซอย|ซ\.)\s*([^\s,]+(?:\s\d+)?)/);
  const roadMatch = text.match(/(?:ถนน|ถ\.)\s*([^\s,]+(?:\s\d+)?)/);
  const subdistrictMatch = text.match(/(?:ตำบล|ต\.|แขวง)\s*([^\s,]+)/);
  const districtMatch = text.match(/(?:อำเภอ|อ\.|เขต)\s*([^\s,]+)/);
  const provinceMatch = text.match(/(?:จังหวัด|จ\.)\s*([^\s,]+)/);
  const postalCodeMatch = text.match(/\b([0-9]{5})\b/);

  return {
    houseNumber: houseNumberMatch?.[1] ?? undefined,
    moo: mooMatch?.[1] ?? undefined,
    soi: soiMatch?.[1] ?? undefined,
    road: roadMatch?.[1] ?? undefined,
    subdistrict: subdistrictMatch?.[1] ?? undefined,
    district: districtMatch?.[1] ?? undefined,
    province: provinceMatch?.[1] ?? undefined,
  };
}

export function extractPostalCode(rawText: string): string | undefined {
  const match = normalizeWhitespace(rawText).match(/\b([0-9]{5})\b/);
  return match?.[1];
}
