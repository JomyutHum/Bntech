import type {
  PrismaClient,
  AwaitingLocationRequest,
  LocationSubmissionAttempt,
  Prisma,
} from "@prisma/client";

export class AwaitingLocationRequestRepository {
  constructor(private readonly prisma: PrismaClient) {}

  async create(
    data: Prisma.AwaitingLocationRequestCreateInput
  ): Promise<AwaitingLocationRequest> {
    return this.prisma.awaitingLocationRequest.create({ data });
  }

  async findActiveByDriverId(
    driverId: string
  ): Promise<AwaitingLocationRequest | null> {
    return this.prisma.awaitingLocationRequest.findFirst({
      where: { driverId, status: "WAITING" },
      orderBy: { createdAt: "desc" },
    });
  }

  async findById(id: string): Promise<AwaitingLocationRequest | null> {
    return this.prisma.awaitingLocationRequest.findUnique({ where: { id } });
  }

  async markFulfilled(id: string): Promise<AwaitingLocationRequest> {
    return this.prisma.awaitingLocationRequest.update({
      where: { id },
      data: { status: "FULFILLED", fulfilledAt: new Date() },
    });
  }

  async recordAttempt(
    data: Prisma.LocationSubmissionAttemptCreateInput
  ): Promise<LocationSubmissionAttempt> {
    return this.prisma.locationSubmissionAttempt.create({ data });
  }
}
