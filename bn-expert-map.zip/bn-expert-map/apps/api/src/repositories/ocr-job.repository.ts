import type { PrismaClient, OcrJob, Prisma, OcrJobStatus } from "@prisma/client";

export class OcrJobRepository {
  constructor(private readonly prisma: PrismaClient) {}

  async findBySourceLineMessageId(
    sourceLineMessageId: string
  ): Promise<OcrJob | null> {
    return this.prisma.ocrJob.findUnique({ where: { sourceLineMessageId } });
  }

  async create(data: Prisma.OcrJobCreateInput): Promise<OcrJob> {
    return this.prisma.ocrJob.create({ data });
  }

  async update(id: string, data: Prisma.OcrJobUpdateInput): Promise<OcrJob> {
    return this.prisma.ocrJob.update({ where: { id }, data });
  }

  async findById(id: string): Promise<OcrJob | null> {
    return this.prisma.ocrJob.findUnique({ where: { id } });
  }

  async list(params: {
    page: number;
    pageSize: number;
    status?: OcrJobStatus;
  }): Promise<{ items: OcrJob[]; totalCount: number }> {
    const where: Prisma.OcrJobWhereInput = params.status
      ? { status: params.status }
      : {};

    const [items, totalCount] = await Promise.all([
      this.prisma.ocrJob.findMany({
        where,
        skip: (params.page - 1) * params.pageSize,
        take: params.pageSize,
        orderBy: { createdAt: "desc" },
      }),
      this.prisma.ocrJob.count({ where }),
    ]);
    return { items, totalCount };
  }
}
