import type { PrismaClient, Coordinate, Prisma } from "@prisma/client";

export interface SearchCoordinatesParams {
  text?: string;
  tag?: string;
  bbox?: { minLat: number; maxLat: number; minLng: number; maxLng: number };
  page: number;
  pageSize: number;
}

export interface PaginatedCoordinates {
  items: Coordinate[];
  totalCount: number;
}

/**
 * CoordinateRepository — all direct Prisma access for the Coordinate
 * model lives here. Services/routes must go through this repository
 * rather than calling prisma.coordinate.* directly (Chapter 1: Repository
 * Pattern, Clean Architecture).
 */
export class CoordinateRepository {
  constructor(private readonly prisma: PrismaClient) {}

  async findById(id: string): Promise<Coordinate | null> {
    return this.prisma.coordinate.findUnique({ where: { id } });
  }

  async findByNormalizedKey(
    normalizedAddressKey: string
  ): Promise<Coordinate | null> {
    return this.prisma.coordinate.findFirst({
      where: { normalizedAddressKey },
      orderBy: { updatedAt: "desc" },
    });
  }

  async create(
    data: Prisma.CoordinateCreateInput
  ): Promise<Coordinate> {
    return this.prisma.coordinate.create({ data });
  }

  async update(
    id: string,
    data: Prisma.CoordinateUpdateInput
  ): Promise<Coordinate> {
    return this.prisma.coordinate.update({ where: { id }, data });
  }

  async delete(id: string): Promise<void> {
    await this.prisma.coordinate.delete({ where: { id } });
  }

  async search(params: SearchCoordinatesParams): Promise<PaginatedCoordinates> {
    const where: Prisma.CoordinateWhereInput = {};

    if (params.text) {
      where.OR = [
        { soi: { contains: params.text, mode: "insensitive" } },
        { road: { contains: params.text, mode: "insensitive" } },
        { subdistrict: { contains: params.text, mode: "insensitive" } },
        { district: { contains: params.text, mode: "insensitive" } },
        { province: { contains: params.text, mode: "insensitive" } },
        { houseNumber: { contains: params.text, mode: "insensitive" } },
        { landmark: { contains: params.text, mode: "insensitive" } },
      ];
    }

    if (params.tag) {
      where.tags = { has: params.tag };
    }

    if (params.bbox) {
      where.latitude = { gte: params.bbox.minLat, lte: params.bbox.maxLat };
      where.longitude = { gte: params.bbox.minLng, lte: params.bbox.maxLng };
    }

    const [items, totalCount] = await Promise.all([
      this.prisma.coordinate.findMany({
        where,
        skip: (params.page - 1) * params.pageSize,
        take: params.pageSize,
        orderBy: { updatedAt: "desc" },
      }),
      this.prisma.coordinate.count({ where }),
    ]);

    return { items, totalCount };
  }

  /** Bounded working set used by CoordinateMatchingService's fuzzy tier. */
  async findRecentForFuzzyMatching(limit = 200): Promise<Coordinate[]> {
    return this.prisma.coordinate.findMany({
      take: limit,
      orderBy: { updatedAt: "desc" },
    });
  }

  async recordHistory(params: {
    coordinateId: string;
    actorType: "DRIVER" | "ADMIN" | "SYSTEM";
    actorId: string;
    action: "CREATED" | "VERIFIED" | "EDITED" | "MERGED";
    diffJson?: Prisma.InputJsonValue;
  }): Promise<void> {
    await this.prisma.coordinateHistory.create({
      data: {
        coordinateId: params.coordinateId,
        actorType: params.actorType,
        actorId: params.actorId,
        action: params.action,
        diffJson: params.diffJson,
      },
    });
  }
}
