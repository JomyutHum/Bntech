import type { PrismaClient, Driver, Prisma } from "@prisma/client";

export class DriverRepository {
  constructor(private readonly prisma: PrismaClient) {}

  async findById(id: string): Promise<Driver | null> {
    return this.prisma.driver.findUnique({ where: { id } });
  }

  async findByLineUserId(lineUserId: string): Promise<Driver | null> {
    return this.prisma.driver.findUnique({ where: { lineUserId } });
  }

  async create(data: Prisma.DriverCreateInput): Promise<Driver> {
    return this.prisma.driver.create({ data });
  }

  async update(id: string, data: Prisma.DriverUpdateInput): Promise<Driver> {
    return this.prisma.driver.update({ where: { id }, data });
  }

  async list(params: {
    page: number;
    pageSize: number;
  }): Promise<{ items: Driver[]; totalCount: number }> {
    const [items, totalCount] = await Promise.all([
      this.prisma.driver.findMany({
        skip: (params.page - 1) * params.pageSize,
        take: params.pageSize,
        orderBy: { createdAt: "desc" },
      }),
      this.prisma.driver.count(),
    ]);
    return { items, totalCount };
  }

  async findOrCreateByLineUserId(
    lineUserId: string,
    displayName: string
  ): Promise<Driver> {
    const existing = await this.findByLineUserId(lineUserId);
    if (existing) return existing;
    return this.create({ lineUserId, displayName });
  }
}
