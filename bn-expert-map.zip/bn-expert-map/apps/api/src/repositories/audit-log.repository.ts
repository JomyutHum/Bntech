import type { PrismaClient, AuditLog, Prisma } from "@prisma/client";

export interface RecordAuditLogParams {
  actorType: "DRIVER" | "ADMIN" | "SYSTEM";
  actorId: string;
  entityType: string;
  entityId: string;
  action: string;
  diffJson?: Prisma.InputJsonValue;
}

/**
 * AuditLogRepository — every write to Coordinate Database, Playlist, and
 * Driver records must call record() (Chapter 2.3). Kept as its own thin
 * repository so it can be injected/called from any service without
 * creating circular dependencies on the larger CoordinateRepository etc.
 */
export class AuditLogRepository {
  constructor(private readonly prisma: PrismaClient) {}

  async record(params: RecordAuditLogParams): Promise<void> {
    await this.prisma.auditLog.create({
      data: {
        actorType: params.actorType,
        actorId: params.actorId,
        entityType: params.entityType,
        entityId: params.entityId,
        action: params.action,
        diffJson: params.diffJson,
      },
    });
  }

  async list(params: {
    page: number;
    pageSize: number;
    entityType?: string;
  }): Promise<{ items: AuditLog[]; totalCount: number }> {
    const where = params.entityType
      ? { entityType: params.entityType }
      : {};

    const [items, totalCount] = await Promise.all([
      this.prisma.auditLog.findMany({
        where,
        skip: (params.page - 1) * params.pageSize,
        take: params.pageSize,
        orderBy: { createdAt: "desc" },
      }),
      this.prisma.auditLog.count({ where }),
    ]);
    return { items, totalCount };
  }
}
