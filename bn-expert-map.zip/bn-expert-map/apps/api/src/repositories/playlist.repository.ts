import type {
  PrismaClient,
  Playlist,
  PlaylistStop,
  Coordinate,
} from "@prisma/client";

export type PlaylistWithStops = Playlist & {
  stops: (PlaylistStop & { coordinate: Coordinate })[];
};

export class PlaylistRepository {
  constructor(private readonly prisma: PrismaClient) {}

  /** Finds today's ACTIVE playlist for a driver, or null if none exists yet. */
  async findActiveForDriverOnDate(
    driverId: string,
    date: Date
  ): Promise<PlaylistWithStops | null> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);

    return this.prisma.playlist.findFirst({
      where: { driverId, playlistDate: startOfDay, status: "ACTIVE" },
      include: {
        stops: {
          where: { status: "PENDING" }, // per spec: completed stops vanish immediately
          orderBy: { orderIndex: "asc" },
          include: { coordinate: true },
        },
      },
    });
  }

  async createForDriverOnDate(
    driverId: string,
    date: Date
  ): Promise<Playlist> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);

    return this.prisma.playlist.create({
      data: { driverId, playlistDate: startOfDay, status: "ACTIVE" },
    });
  }

  async addStop(params: {
    playlistId: string;
    coordinateId: string;
    orderIndex: number;
  }): Promise<PlaylistStop> {
    return this.prisma.playlistStop.create({
      data: {
        playlistId: params.playlistId,
        coordinateId: params.coordinateId,
        orderIndex: params.orderIndex,
        status: "PENDING",
      },
    });
  }

  async updateStopStatus(params: {
    stopId: string;
    status: "PENDING" | "DELIVERED" | "SKIPPED" | "PROBLEM";
    problemNote?: string;
  }): Promise<PlaylistStop> {
    const isTerminal =
      params.status === "DELIVERED" || params.status === "SKIPPED";

    return this.prisma.playlistStop.update({
      where: { id: params.stopId },
      data: {
        status: params.status,
        problemNote: params.problemNote,
        completedAt: isTerminal ? new Date() : undefined,
      },
    });
  }

  async updateStopDistanceEta(params: {
    stopId: string;
    distanceMeters: number;
    etaMinutes: number;
  }): Promise<void> {
    await this.prisma.playlistStop.update({
      where: { id: params.stopId },
      data: {
        distanceMeters: params.distanceMeters,
        etaMinutes: params.etaMinutes,
      },
    });
  }

  /** Re-numbers orderIndex for all PENDING stops to match the given order. */
  async reorderStops(
    playlistId: string,
    orderedStopIds: string[]
  ): Promise<void> {
    await this.prisma.$transaction(
      orderedStopIds.map((stopId, index) =>
        this.prisma.playlistStop.update({
          where: { id: stopId },
          data: { orderIndex: index },
        })
      )
    );
    // playlistId kept for signature clarity / future per-playlist locking;
    // not used directly since stopId is already globally unique.
    void playlistId;
  }

  async findStopById(stopId: string): Promise<PlaylistStop | null> {
    return this.prisma.playlistStop.findUnique({ where: { id: stopId } });
  }

  async listForDriverInRange(params: {
    driverId?: string;
    from: Date;
    to: Date;
  }): Promise<PlaylistWithStops[]> {
    return this.prisma.playlist.findMany({
      where: {
        driverId: params.driverId,
        playlistDate: { gte: params.from, lte: params.to },
      },
      include: {
        stops: { include: { coordinate: true }, orderBy: { orderIndex: "asc" } },
      },
      orderBy: { playlistDate: "desc" },
    });
  }
}
