import type { PrismaClient, AdminUser, Prisma } from "@prisma/client";

export class AdminRepository {
  constructor(private readonly prisma: PrismaClient) {}

  async findById(id: string): Promise<AdminUser | null> {
    return this.prisma.adminUser.findUnique({ where: { id } });
  }

  async findByEmail(email: string): Promise<AdminUser | null> {
    return this.prisma.adminUser.findUnique({ where: { email } });
  }

  async create(data: Prisma.AdminUserCreateInput): Promise<AdminUser> {
    return this.prisma.adminUser.create({ data });
  }
}
