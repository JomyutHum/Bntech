import Fastify from "fastify";
import cors from "@fastify/cors";
import { loadEnv } from "./config/env.js";
import { registerRateLimit } from "./middleware/rate-limit.middleware.js";
import { lineRoutes } from "./routes/line.routes.js";
import { authRoutes } from "./routes/auth.routes.js";
import { coordinateRoutes } from "./routes/coordinates.routes.js";
import { playlistRoutes } from "./routes/playlists.routes.js";
import { driverRoutes } from "./routes/drivers.routes.js";
import { ocrJobRoutes } from "./routes/ocr-jobs.routes.js";
import { auditLogRoutes } from "./routes/audit-logs.routes.js";
import { reportRoutes } from "./routes/reports.routes.js";

async function buildServer() {
  const env = loadEnv();

  const app = Fastify({
    logger: {
      level: env.NODE_ENV === "production" ? "info" : "debug",
    },
    // Capture the raw request body string so the LINE webhook route can
    // verify the HMAC signature against the exact bytes LINE signed.
    bodyLimit: 10 * 1024 * 1024, // 10MB, generous enough for image-bearing webhook payloads
  });

  // Preserve the raw request body string so the LINE webhook route can
  // verify the HMAC signature against the exact bytes LINE signed. This
  // uses Fastify's documented content-type-parser override mechanism
  // (rather than a custom stream-reconstruction hook) specifically for
  // the LINE webhook content type, since signature verification is
  // security-critical and must use the exact raw bytes, not a
  // re-serialized JSON.parse(JSON.stringify(...)) round trip.
  app.addContentTypeParser(
    "application/json",
    { parseAs: "string" },
    (request, body, done) => {
      (request as { rawBody?: string }).rawBody = body as string;
      try {
        const json = body ? JSON.parse(body as string) : {};
        done(null, json);
      } catch (error) {
        done(error as Error, undefined);
      }
    }
  );

  await app.register(cors, {
    origin: env.NODE_ENV === "production" ? false : true,
    // REQUIRES_USER_SETUP: in production, replace `false` above with the
    // actual deployed Next.js origin (e.g. "https://app.bn-expert-map.com")
    // once the domain is known.
  });

  await registerRateLimit(app);

  await app.register(lineRoutes);
  await app.register(authRoutes);
  await app.register(coordinateRoutes);
  await app.register(playlistRoutes);
  await app.register(driverRoutes);
  await app.register(ocrJobRoutes);
  await app.register(auditLogRoutes);
  await app.register(reportRoutes);

  app.get("/health", async () => ({ success: true, data: { status: "ok" } }));

  return app;
}

async function start(): Promise<void> {
  const app = await buildServer();
  const env = loadEnv();

  try {
    await app.listen({ port: env.PORT, host: "0.0.0.0" });
  } catch (error) {
    app.log.error(error);
    process.exit(1);
  }
}

start();
