import type { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { prisma } from "../config/prisma.js";
import { LineWebhookService } from "../services/line-webhook.service.js";
import { LineMessagingClient } from "../services/line-messaging.client.js";
import { OcrPipelineService } from "../services/ocr-pipeline.service.js";
import { LocationConfirmationService } from "../services/location-confirmation.service.js";
import { LocationLinkResolverService } from "../services/location-link-resolver.service.js";
import { MissingLiveGpsReadingError } from "../services/proximity-verification.service.js";
import { DriverRepository } from "../repositories/driver.repository.js";
import { AwaitingLocationRequestRepository } from "../repositories/awaiting-location-request.repository.js";
import { PlaylistService } from "../services/playlist.service.js";

interface LineWebhookBody {
  destination: string;
  events: LineEvent[];
}

interface LineEvent {
  type: string;
  webhookEventId: string;
  replyToken?: string;
  source: { type: string; userId?: string };
  message?: {
    id: string;
    type: string;
    text?: string;
    latitude?: number;
    longitude?: number;
  };
}

const webhookService = new LineWebhookService();
const lineClient = new LineMessagingClient();
const linkResolver = new LocationLinkResolverService();
const driverRepo = new DriverRepository(prisma);
const awaitingRepo = new AwaitingLocationRequestRepository(prisma);

export async function lineRoutes(app: FastifyInstance): Promise<void> {
  app.post(
    "/api/v1/line/webhook",
    {
      config: { rateLimit: { max: 60, timeWindow: "1 minute" } },
    },
    async (request: FastifyRequest, reply: FastifyReply) => {
      const rawBody = (request as { rawBody?: string }).rawBody ?? JSON.stringify(request.body);
      const signature = request.headers["x-line-signature"] as string | undefined;

      if (!webhookService.verifySignature(rawBody, signature)) {
        return reply.code(401).send({
          success: false,
          error: { code: "INVALID_SIGNATURE", message: "LINE signature verification failed" },
        });
      }

      const body = request.body as LineWebhookBody;

      // Acknowledge immediately; process events without blocking LINE's
      // retry logic (LINE expects a fast 200).
      reply.code(200).send({ success: true });

      for (const event of body.events) {
        try {
          await handleEvent(event);
        } catch (error) {
          app.log.error({ error, event }, "Failed to handle LINE event");
        }
      }
    }
  );
}

async function handleEvent(event: LineEvent): Promise<void> {
  const isDuplicate = await webhookService.isDuplicateEvent(event.webhookEventId);
  if (isDuplicate) return;

  const lineUserId = event.source.userId;
  if (!lineUserId) return;

  const driver = await driverRepo.findOrCreateByLineUserId(lineUserId, "ไม่ระบุชื่อ");

  if (event.type === "message" && event.message?.type === "image") {
    await handleImageMessage(driver.id, event);
    return;
  }

  if (event.type === "message" && event.message?.type === "location") {
    await handleLocationMessage(driver.id, event);
    return;
  }

  if (event.type === "message" && event.message?.type === "text") {
    await handleTextMessage(driver.id, event);
    return;
  }
}

async function handleImageMessage(driverId: string, event: LineEvent): Promise<void> {
  if (!event.message || !event.replyToken) return;

  // NOTE: fetching the actual binary image content from LINE's content
  // API requires an authenticated GET to
  // https://api-data.line.me/v2/bot/message/{messageId}/content using the
  // channel access token. That HTTP call is omitted here for brevity but
  // MUST be implemented exactly per LINE's Messaging API docs before this
  // handler is production-ready — see REQUIRES_USER_SETUP note in
  // DEPLOYMENT.md regarding LINE_CHANNEL_ACCESS_TOKEN usage.
  const imageBuffer = await fetchLineImageContent(event.message.id);

  const ocrPipeline = new OcrPipelineService(prisma);
  const outcome = await ocrPipeline.process({
    driverId,
    sourceLineMessageId: event.message.id,
    imageBuffer,
    imageContentType: "image/jpeg",
    imageFileExtension: "jpg",
  });

  if (outcome.outcome === "MATCHED") {
    await lineClient.replyWithQuickReply(
      event.replyToken,
      "เจอพิกัดที่ยืนยันแล้วในระบบครับ! กดเพิ่มเข้า Playlist วันนี้ได้เลย",
      [{ label: "เพิ่มเข้า Playlist วันนี้", data: `add_playlist:${outcome.coordinateId}` }]
    );
    return;
  }

  if (outcome.outcome === "AWAITING_LOCATION") {
    await lineClient.requestLocation(
      event.replyToken,
      "ยังไม่มีพิกัดที่อยู่นี้ในระบบครับ พอถึงหน้าบ้านแล้วช่วยแชร์พิกัดหรือแปะลิงก์แผนที่ให้ด้วยนะครับ"
    );
    return;
  }

  if (outcome.outcome === "POSSIBLE_DUPLICATE") {
    await lineClient.replyText(
      event.replyToken,
      "เจอที่อยู่ใกล้เคียงในระบบ แต่ยังไม่แน่ใจว่าตรงกันไหม รอแอดมินตรวจสอบก่อนนะครับ"
    );
    return;
  }

  await lineClient.replyText(
    event.replyToken,
    "ขออภัยครับ ระบบอ่านที่อยู่จากภาพไม่สำเร็จ รบกวนส่งภาพที่ชัดกว่านี้อีกครั้งได้ไหมครับ"
  );
}

async function handleLocationMessage(driverId: string, event: LineEvent): Promise<void> {
  if (!event.message || !event.replyToken) return;
  if (event.message.latitude === undefined || event.message.longitude === undefined) return;

  const awaitingRequest = await awaitingRepo.findActiveByDriverId(driverId);
  if (!awaitingRequest) {
    // No pending request — a bare location share with nothing to fulfill.
    await lineClient.replyText(
      event.replyToken,
      "ขอบคุณสำหรับพิกัดครับ แต่ตอนนี้ไม่มีรายการที่รอการยืนยันพิกัดอยู่นะครับ"
    );
    return;
  }

  const candidateCoordinate = {
    latitude: event.message.latitude,
    longitude: event.message.longitude,
  };

  // Per Chapter 4A: the LINE Location share itself doubles as both the
  // candidate coordinate AND, when sent promptly, the driver's live GPS
  // reading (since LINE's location share reflects the device's current
  // position at send time).
  const locationConfirmation = new LocationConfirmationService(prisma);

  try {
    const result = await locationConfirmation.fulfill({
      awaitingLocationRequestId: awaitingRequest.id,
      candidateCoordinate,
      driverLiveGps: candidateCoordinate,
    });

    await replyForLocationOutcome(event.replyToken, result);
  } catch (error) {
    if (error instanceof MissingLiveGpsReadingError) {
      await lineClient.replyText(
        event.replyToken,
        "ระบบต้องการตำแหน่งปัจจุบันของคุณเพื่อยืนยัน กรุณาแชร์พิกัดอีกครั้งครับ"
      );
      return;
    }
    throw error;
  }
}

async function handleTextMessage(driverId: string, event: LineEvent): Promise<void> {
  if (!event.message?.text || !event.replyToken) return;
  const text = event.message.text.trim();

  if (text === "playlist" || text === "งานวันนี้") {
    const playlistService = new PlaylistService(prisma);
    const playlist = await playlistService.getOrCreateTodayPlaylist(driverId);
    const remaining = playlist.stops.length;
    const next = playlist.stops[0];
    const nextLabel = next
      ? `${next.coordinate.soi ?? ""} ${next.coordinate.road ?? ""}`.trim() || "(ไม่มีชื่อที่อยู่)"
      : "ไม่มีงานเหลือแล้ว";
    await lineClient.replyText(
      event.replyToken,
      `งานวันนี้เหลือ ${remaining} จุด\nจุดต่อไป: ${nextLabel}`
    );
    return;
  }

  // Check if this text is a map link the driver is pasting to fulfill a
  // pending AwaitingLocationRequest.
  const provider = linkResolver.detectProvider(text);
  if (provider !== "UNKNOWN") {
    const awaitingRequest = await awaitingRepo.findActiveByDriverId(driverId);
    if (awaitingRequest) {
      await lineClient.replyText(
        event.replyToken,
        "ได้รับลิงก์แล้วครับ กรุณาแชร์พิกัดปัจจุบันของคุณเพื่อยืนยันด้วยนะครับ"
      );
      // The actual fulfillment (resolving the link + checking proximity)
      // happens once the driver's live-location follow-up message
      // arrives — see Chapter 4A note on LINE's lack of an on-demand
      // location pull. A production implementation should persist this
      // raw link text against the AwaitingLocationRequest (e.g. a short
      // Redis-backed "pending link" keyed by driverId) so the subsequent
      // location message can be combined with it. That glue is left as a
      // REQUIRES_USER_SETUP-adjacent TODO for the next iteration — see
      // DEPLOYMENT.md.
    }
    return;
  }

  // Fallback: unrecognized command.
  await lineClient.replyText(
    event.replyToken,
    "พิมพ์ 'playlist' เพื่อดูงานวันนี้ครับ"
  );
}

async function replyForLocationOutcome(
  replyToken: string,
  result: Awaited<ReturnType<LocationConfirmationService["fulfill"]>>
): Promise<void> {
  if (result.result === "ACCEPTED") {
    await lineClient.replyWithQuickReply(
      replyToken,
      `บันทึกพิกัดสำเร็จครับ (ห่างจากตำแหน่งคุณ ${Math.round(result.distanceMeters)} เมตร)`,
      [{ label: "เพิ่มเข้า Playlist วันนี้", data: `add_playlist:${result.coordinateId}` }]
    );
    return;
  }

  if (result.result === "REJECTED_TOO_FAR") {
    await lineClient.replyText(
      replyToken,
      `พิกัดที่ส่งมาห่างจากตำแหน่งปัจจุบันคุณ ${Math.round(result.distanceMeters)} เมตร ` +
        "ซึ่งเกินกว่าที่ระบบยอมรับ (150 เมตร) กรุณาส่งใหม่ตอนอยู่ใกล้บ้านจริง ๆ นะครับ"
    );
    return;
  }

  await lineClient.replyText(
    replyToken,
    "ขออภัยครับ ระบบไม่สามารถอ่านพิกัดจากลิงก์ที่ส่งมาได้ ลองแชร์พิกัดผ่าน LINE Location แทนได้ไหมครับ"
  );
}

/**
 * Fetches the binary content of an image message from LINE's content API.
 * REQUIRES_USER_SETUP context: needs a valid LINE_CHANNEL_ACCESS_TOKEN.
 */
async function fetchLineImageContent(messageId: string): Promise<Buffer> {
  const { loadEnv } = await import("../config/env.js");
  const env = loadEnv();

  const response = await fetch(
    `https://api-data.line.me/v2/bot/message/${messageId}/content`,
    {
      headers: { Authorization: `Bearer ${env.LINE_CHANNEL_ACCESS_TOKEN}` },
    }
  );

  if (!response.ok) {
    throw new Error(`Failed to fetch LINE image content: ${response.status}`);
  }

  const arrayBuffer = await response.arrayBuffer();
  return Buffer.from(arrayBuffer);
}
