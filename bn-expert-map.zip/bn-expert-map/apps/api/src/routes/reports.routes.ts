import type { FastifyInstance } from "fastify";
import { prisma } from "../config/prisma.js";
import { requireAuth, requireAdmin } from "../middleware/auth.middleware.js";
import { validateQuery } from "../middleware/validation.middleware.js";
import { reportSummaryQuerySchema, ok, type ReportSummaryQuery } from "@bn-expert-map/shared";

export async function reportRoutes(app: FastifyInstance): Promise<void> {
  app.get(
    "/api/v1/reports/summary",
    { preHandler: [requireAuth, requireAdmin, validateQuery(reportSummaryQuerySchema)] },
    async (request, reply) => {
      const { from, to } = request.query as ReportSummaryQuery;
      const fromDate = new Date(from);
      const toDate = new Date(to);

      const [
        totalDeliveredStops,
        totalOcrJobs,
        noMatchOcrJobs,
        deliveriesByDriver,
      ] = await Promise.all([
        prisma.playlistStop.count({
          where: { status: "DELIVERED", completedAt: { gte: fromDate, lte: toDate } },
        }),
        prisma.ocrJob.count({
          where: { createdAt: { gte: fromDate, lte: toDate } },
        }),
        prisma.ocrJob.count({
          where: {
            createdAt: { gte: fromDate, lte: toDate },
            status: { in: ["NO_MATCH", "AWAITING_LOCATION"] },
          },
        }),
        prisma.playlistStop.groupBy({
          by: ["playlistId"],
          where: { status: "DELIVERED", completedAt: { gte: fromDate, lte: toDate } },
          _count: { id: true },
        }),
      ]);

      const noMatchRate =
        totalOcrJobs > 0 ? noMatchOcrJobs / totalOcrJobs : 0;

      return reply.send(
        ok({
          rangeStart: from,
          rangeEnd: to,
          totalDeliveredStops,
          totalOcrJobs,
          noMatchOcrJobs,
          noMatchRate,
          distinctPlaylistsWithDeliveries: deliveriesByDriver.length,
        })
      );
    }
  );
}
