import type { FastifyInstance } from "fastify";
import { prisma } from "../config/prisma.js";
import { OcrJobRepository } from "../repositories/ocr-job.repository.js";
import { requireAuth, requireAdmin } from "../middleware/auth.middleware.js";
import { validateQuery } from "../middleware/validation.middleware.js";
import { paginationQuerySchema, ok, fail, type PaginationQuery } from "@bn-expert-map/shared";

const ocrJobRepo = new OcrJobRepository(prisma);

export async function ocrJobRoutes(app: FastifyInstance): Promise<void> {
  app.get(
    "/api/v1/ocr-jobs",
    { preHandler: [requireAuth, requireAdmin, validateQuery(paginationQuerySchema)] },
    async (request, reply) => {
      const query = request.query as PaginationQuery;
      const result = await ocrJobRepo.list(query);
      return reply.send(
        ok({
          items: result.items,
          page: query.page,
          pageSize: query.pageSize,
          totalCount: result.totalCount,
          totalPages: Math.ceil(result.totalCount / query.pageSize),
        })
      );
    }
  );

  app.get(
    "/api/v1/ocr-jobs/:id",
    { preHandler: [requireAuth, requireAdmin] },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const job = await ocrJobRepo.findById(id);
      if (!job) {
        return reply.code(404).send(fail("NOT_FOUND", "OCR job not found"));
      }
      return reply.send(ok(job));
    }
  );
}
