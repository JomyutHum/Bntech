import type { FastifyInstance } from "fastify";
import { prisma } from "../config/prisma.js";
import { DriverRepository } from "../repositories/driver.repository.js";
import { AuditLogRepository } from "../repositories/audit-log.repository.js";
import { requireAuth, requireAdmin } from "../middleware/auth.middleware.js";
import { validateBody, validateQuery } from "../middleware/validation.middleware.js";
import {
  createDriverSchema,
  updateDriverSchema,
  paginationQuerySchema,
  ok,
  fail,
  type CreateDriverInput,
  type UpdateDriverInput,
  type PaginationQuery,
  type AdminJwtPayload,
} from "@bn-expert-map/shared";

const driverRepo = new DriverRepository(prisma);
const auditLogRepo = new AuditLogRepository(prisma);

export async function driverRoutes(app: FastifyInstance): Promise<void> {
  app.get(
    "/api/v1/drivers",
    { preHandler: [requireAuth, requireAdmin, validateQuery(paginationQuerySchema)] },
    async (request, reply) => {
      const query = request.query as PaginationQuery;
      const result = await driverRepo.list(query);
      return reply.send(
        ok({
          items: result.items,
          page: query.page,
          pageSize: query.pageSize,
          totalCount: result.totalCount,
          totalPages: Math.ceil(result.totalCount / query.pageSize),
        })
      );
    }
  );

  app.post(
    "/api/v1/drivers",
    { preHandler: [requireAuth, requireAdmin, validateBody(createDriverSchema)] },
    async (request, reply) => {
      const input = request.body as CreateDriverInput;
      const adminUser = request.authUser as AdminJwtPayload;

      const existing = await driverRepo.findByLineUserId(input.lineUserId);
      if (existing) {
        return reply
          .code(409)
          .send(fail("DRIVER_EXISTS", "A driver with this LINE user ID already exists"));
      }

      const driver = await driverRepo.create(input);

      await auditLogRepo.record({
        actorType: "ADMIN",
        actorId: adminUser.sub,
        entityType: "Driver",
        entityId: driver.id,
        action: "CREATED",
      });

      return reply.code(201).send(ok(driver));
    }
  );

  app.patch(
    "/api/v1/drivers/:id",
    { preHandler: [requireAuth, requireAdmin, validateBody(updateDriverSchema)] },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const input = request.body as UpdateDriverInput;
      const adminUser = request.authUser as AdminJwtPayload;

      const existing = await driverRepo.findById(id);
      if (!existing) {
        return reply.code(404).send(fail("NOT_FOUND", "Driver not found"));
      }

      const updated = await driverRepo.update(id, input);

      await auditLogRepo.record({
        actorType: "ADMIN",
        actorId: adminUser.sub,
        entityType: "Driver",
        entityId: id,
        action: "EDITED",
        diffJson: input,
      });

      return reply.send(ok(updated));
    }
  );
}
