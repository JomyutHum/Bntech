import type { FastifyInstance } from "fastify";
import { prisma } from "../config/prisma.js";
import { PlaylistService } from "../services/playlist.service.js";
import { requireAuth } from "../middleware/auth.middleware.js";
import { validateBody, validateQuery } from "../middleware/validation.middleware.js";
import {
  addPlaylistStopSchema,
  updatePlaylistStopSchema,
  todayPlaylistQuerySchema,
  ok,
  fail,
  isAdminPayload,
  type AddPlaylistStopInput,
  type UpdatePlaylistStopInput,
  type TodayPlaylistQuery,
  type DriverJwtPayload,
} from "@bn-expert-map/shared";

const playlistService = new PlaylistService(prisma);

export async function playlistRoutes(app: FastifyInstance): Promise<void> {
  app.get(
    "/api/v1/playlists/today",
    { preHandler: [requireAuth, validateQuery(todayPlaylistQuerySchema)] },
    async (request, reply) => {
      const query = request.query as TodayPlaylistQuery;
      const authUser = request.authUser!;

      let driverId: string;
      if (isAdminPayload(authUser)) {
        if (!query.driverId) {
          return reply
            .code(400)
            .send(fail("MISSING_DRIVER_ID", "driverId query param is required for admin requests"));
        }
        driverId = query.driverId;
      } else {
        driverId = (authUser as DriverJwtPayload).sub;
      }

      const playlist = await playlistService.getOrCreateTodayPlaylist(driverId);
      return reply.send(ok(playlist));
    }
  );

  app.post(
    "/api/v1/playlists/:id/stops",
    { preHandler: [requireAuth, validateBody(addPlaylistStopSchema)] },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const { coordinateId } = request.body as AddPlaylistStopInput;
      const authUser = request.authUser!;

      await playlistService.addStop({
        playlistId: id,
        coordinateId,
        actorType: isAdminPayload(authUser) ? "ADMIN" : "DRIVER",
        actorId: authUser.sub,
      });

      return reply.code(201).send(ok({ added: true }));
    }
  );

  app.patch(
    "/api/v1/playlists/:playlistId/stops/:stopId",
    { preHandler: [requireAuth, validateBody(updatePlaylistStopSchema)] },
    async (request, reply) => {
      const { stopId } = request.params as { playlistId: string; stopId: string };
      const { status, problemNote } = request.body as UpdatePlaylistStopInput;
      const authUser = request.authUser!;

      if (status === "PENDING") {
        return reply
          .code(400)
          .send(fail("INVALID_STATUS", "Cannot manually set status back to PENDING"));
      }

      await playlistService.markStopStatus({
        stopId,
        status,
        problemNote,
        actorType: isAdminPayload(authUser) ? "ADMIN" : "DRIVER",
        actorId: authUser.sub,
      });

      return reply.send(ok({ updated: true }));
    }
  );
}
