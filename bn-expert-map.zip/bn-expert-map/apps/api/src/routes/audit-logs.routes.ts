import type { FastifyInstance } from "fastify";
import { prisma } from "../config/prisma.js";
import { AuditLogRepository } from "../repositories/audit-log.repository.js";
import { requireAuth, requireAdmin } from "../middleware/auth.middleware.js";
import { validateQuery } from "../middleware/validation.middleware.js";
import { paginationQuerySchema, ok, type PaginationQuery } from "@bn-expert-map/shared";

const auditLogRepo = new AuditLogRepository(prisma);

export async function auditLogRoutes(app: FastifyInstance): Promise<void> {
  app.get(
    "/api/v1/audit-logs",
    { preHandler: [requireAuth, requireAdmin, validateQuery(paginationQuerySchema)] },
    async (request, reply) => {
      const query = request.query as PaginationQuery & { entityType?: string };
      const result = await auditLogRepo.list({
        page: query.page,
        pageSize: query.pageSize,
        entityType: query.entityType,
      });
      return reply.send(
        ok({
          items: result.items,
          page: query.page,
          pageSize: query.pageSize,
          totalCount: result.totalCount,
          totalPages: Math.ceil(result.totalCount / query.pageSize),
        })
      );
    }
  );
}
