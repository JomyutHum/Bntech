import type { FastifyInstance } from "fastify";
import { prisma } from "../config/prisma.js";
import { loadEnv } from "../config/env.js";
import { AuthService } from "../services/auth.service.js";
import { DriverRepository } from "../repositories/driver.repository.js";
import { AdminRepository } from "../repositories/admin.repository.js";
import { validateBody } from "../middleware/validation.middleware.js";
import {
  lineLoginCallbackSchema,
  adminLoginSchema,
  ok,
  fail,
  type LineLoginCallbackInput,
  type AdminLoginInput,
} from "@bn-expert-map/shared";

const authService = new AuthService();
const driverRepo = new DriverRepository(prisma);
const adminRepo = new AdminRepository(prisma);

interface LineTokenResponse {
  access_token: string;
  id_token: string;
}

interface LineProfileFromIdToken {
  sub: string; // LINE user ID
  name: string;
}

export async function authRoutes(app: FastifyInstance): Promise<void> {
  app.post(
    "/api/v1/auth/line/callback",
    { preHandler: validateBody(lineLoginCallbackSchema) },
    async (request, reply) => {
      const { code, redirectUri } = request.body as LineLoginCallbackInput;
      const env = loadEnv();

      const tokenResponse = await fetch("https://api.line.me/oauth2/v2.1/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          grant_type: "authorization_code",
          code,
          redirect_uri: redirectUri,
          client_id: env.LINE_LOGIN_CHANNEL_ID,
          client_secret: env.LINE_LOGIN_CHANNEL_SECRET,
        }).toString(),
      });

      if (!tokenResponse.ok) {
        return reply
          .code(401)
          .send(fail("LINE_LOGIN_FAILED", "Failed to exchange LINE login code"));
      }

      const tokenData = (await tokenResponse.json()) as LineTokenResponse;
      const profile = decodeLineIdToken(tokenData.id_token);

      const driver = await driverRepo.findOrCreateByLineUserId(
        profile.sub,
        profile.name
      );

      if (!driver.isActive) {
        return reply
          .code(403)
          .send(fail("DRIVER_INACTIVE", "This driver account has been deactivated"));
      }

      const jwtToken = authService.issueDriverToken({
        sub: driver.id,
        lineUserId: driver.lineUserId,
      });

      return reply.send(ok({ token: jwtToken, driver }));
    }
  );

  app.post(
    "/api/v1/auth/admin/login",
    { preHandler: validateBody(adminLoginSchema) },
    async (request, reply) => {
      const { email, password } = request.body as AdminLoginInput;

      const admin = await adminRepo.findByEmail(email);
      if (!admin) {
        return reply
          .code(401)
          .send(fail("INVALID_CREDENTIALS", "Invalid email or password"));
      }

      const passwordMatches = await authService.verifyPassword(
        password,
        admin.passwordHash
      );
      if (!passwordMatches) {
        return reply
          .code(401)
          .send(fail("INVALID_CREDENTIALS", "Invalid email or password"));
      }

      const jwtToken = authService.issueAdminToken({
        sub: admin.id,
        email: admin.email,
      });

      return reply.send(
        ok({ token: jwtToken, admin: { id: admin.id, email: admin.email, displayName: admin.displayName } })
      );
    }
  );
}

/**
 * Decodes the LINE ID token (a JWT) to extract the user's LINE sub +
 * display name. This does NOT verify the JWT signature against LINE's
 * public keys — a production-hardened implementation should verify the
 * signature using LINE's JWKS endpoint. Marked for follow-up hardening.
 */
function decodeLineIdToken(idToken: string): LineProfileFromIdToken {
  const payloadSegment = idToken.split(".")[1];
  if (!payloadSegment) {
    throw new Error("Malformed LINE ID token");
  }
  const decoded = Buffer.from(payloadSegment, "base64url").toString("utf-8");
  const payload = JSON.parse(decoded) as { sub: string; name?: string };
  return { sub: payload.sub, name: payload.name ?? "ไม่ระบุชื่อ" };
}
