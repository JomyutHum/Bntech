import type { FastifyInstance } from "fastify";
import { prisma } from "../config/prisma.js";
import { CoordinateRepository } from "../repositories/coordinate.repository.js";
import { CoordinateMatchingService } from "../services/coordinate-matching.service.js";
import { AuditLogRepository } from "../repositories/audit-log.repository.js";
import { requireAuth, requireAdmin } from "../middleware/auth.middleware.js";
import { validateBody, validateQuery } from "../middleware/validation.middleware.js";
import {
  createCoordinateSchema,
  updateCoordinateSchema,
  searchCoordinatesQuerySchema,
  mergeCoordinatesSchema,
  ok,
  fail,
  type CreateCoordinateInput,
  type UpdateCoordinateInput,
  type SearchCoordinatesQuery,
  type MergeCoordinatesInput,
} from "@bn-expert-map/shared";
import { buildNormalizedAddressKey } from "../utils/address-normalizer.js";
import type { AdminJwtPayload } from "@bn-expert-map/shared";

const coordinateRepo = new CoordinateRepository(prisma);
const matchingService = new CoordinateMatchingService(prisma);
const auditLogRepo = new AuditLogRepository(prisma);

export async function coordinateRoutes(app: FastifyInstance): Promise<void> {
  app.get(
    "/api/v1/coordinates",
    {
      preHandler: [requireAuth, validateQuery(searchCoordinatesQuerySchema)],
    },
    async (request, reply) => {
      const query = request.query as SearchCoordinatesQuery;
      const bbox =
        query.minLat !== undefined &&
        query.maxLat !== undefined &&
        query.minLng !== undefined &&
        query.maxLng !== undefined
          ? {
              minLat: query.minLat,
              maxLat: query.maxLat,
              minLng: query.minLng,
              maxLng: query.maxLng,
            }
          : undefined;

      const result = await coordinateRepo.search({
        text: query.text,
        tag: query.tag,
        bbox,
        page: query.page,
        pageSize: query.pageSize,
      });

      return reply.send(
        ok({
          items: result.items,
          page: query.page,
          pageSize: query.pageSize,
          totalCount: result.totalCount,
          totalPages: Math.ceil(result.totalCount / query.pageSize),
        })
      );
    }
  );

  app.get(
    "/api/v1/coordinates/:id",
    { preHandler: requireAuth },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const coordinate = await coordinateRepo.findById(id);
      if (!coordinate) {
        return reply.code(404).send(fail("NOT_FOUND", "Coordinate not found"));
      }
      return reply.send(ok(coordinate));
    }
  );

  app.post(
    "/api/v1/coordinates",
    {
      preHandler: [requireAuth, requireAdmin, validateBody(createCoordinateSchema)],
    },
    async (request, reply) => {
      const input = request.body as CreateCoordinateInput;
      const adminUser = request.authUser as AdminJwtPayload;

      const normalizedAddressKey = buildNormalizedAddressKey(input);

      const coordinate = await coordinateRepo.create({
        ...input,
        normalizedAddressKey,
        verifiedByAdmin: { connect: { id: adminUser.sub } },
      });

      await coordinateRepo.recordHistory({
        coordinateId: coordinate.id,
        actorType: "ADMIN",
        actorId: adminUser.sub,
        action: "CREATED",
      });

      await auditLogRepo.record({
        actorType: "ADMIN",
        actorId: adminUser.sub,
        entityType: "Coordinate",
        entityId: coordinate.id,
        action: "CREATED",
      });

      return reply.code(201).send(ok(coordinate));
    }
  );

  app.patch(
    "/api/v1/coordinates/:id",
    {
      preHandler: [requireAuth, requireAdmin, validateBody(updateCoordinateSchema)],
    },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const input = request.body as UpdateCoordinateInput;
      const adminUser = request.authUser as AdminJwtPayload;

      const existing = await coordinateRepo.findById(id);
      if (!existing) {
        return reply.code(404).send(fail("NOT_FOUND", "Coordinate not found"));
      }

      const mergedFields = { ...existing, ...input };
      const normalizedAddressKey = buildNormalizedAddressKey(mergedFields);

      const updated = await coordinateRepo.update(id, {
        ...input,
        normalizedAddressKey,
      });

      await coordinateRepo.recordHistory({
        coordinateId: id,
        actorType: "ADMIN",
        actorId: adminUser.sub,
        action: "EDITED",
        // JSON round-trip strips `undefined` properties (left over from
        // the partial Zod schema), which Prisma's InputJsonValue type
        // does not accept — only defined JSON-serializable values.
        diffJson: JSON.parse(JSON.stringify(input)),
      });

      await auditLogRepo.record({
        actorType: "ADMIN",
        actorId: adminUser.sub,
        entityType: "Coordinate",
        entityId: id,
        action: "EDITED",
        diffJson: JSON.parse(JSON.stringify(input)),
      });

      return reply.send(ok(updated));
    }
  );

  app.delete(
    "/api/v1/coordinates/:id",
    { preHandler: [requireAuth, requireAdmin] },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const adminUser = request.authUser as AdminJwtPayload;

      const existing = await coordinateRepo.findById(id);
      if (!existing) {
        return reply.code(404).send(fail("NOT_FOUND", "Coordinate not found"));
      }

      await coordinateRepo.delete(id);

      await auditLogRepo.record({
        actorType: "ADMIN",
        actorId: adminUser.sub,
        entityType: "Coordinate",
        entityId: id,
        action: "DELETED",
      });

      return reply.code(204).send();
    }
  );

  app.get(
    "/api/v1/coordinates/:id/duplicates",
    { preHandler: [requireAuth, requireAdmin] },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const coordinate = await coordinateRepo.findById(id);
      if (!coordinate) {
        return reply.code(404).send(fail("NOT_FOUND", "Coordinate not found"));
      }

      const matchResult = await matchingService.findMatch(coordinate, {
        latitude: coordinate.latitude,
        longitude: coordinate.longitude,
      });

      const candidates = (matchResult.candidates ?? []).filter(
        (c) => c.coordinate.id !== id
      );

      return reply.send(ok(candidates));
    }
  );

  app.post(
    "/api/v1/coordinates/:id/merge",
    {
      preHandler: [requireAuth, requireAdmin, validateBody(mergeCoordinatesSchema)],
    },
    async (request, reply) => {
      const { id } = request.params as { id: string };
      const { duplicateCoordinateId } = request.body as MergeCoordinatesInput;
      const adminUser = request.authUser as AdminJwtPayload;

      const primary = await coordinateRepo.findById(id);
      const duplicate = await coordinateRepo.findById(duplicateCoordinateId);

      if (!primary || !duplicate) {
        return reply
          .code(404)
          .send(fail("NOT_FOUND", "One or both coordinates not found"));
      }

      // Re-point any PlaylistStop / OcrJob references from the duplicate to
      // the primary, then delete the duplicate record. Done as a
      // transaction so partial merges never happen.
      await prisma.$transaction([
        prisma.playlistStop.updateMany({
          where: { coordinateId: duplicateCoordinateId },
          data: { coordinateId: id },
        }),
        prisma.ocrJob.updateMany({
          where: { matchedCoordinateId: duplicateCoordinateId },
          data: { matchedCoordinateId: id },
        }),
        prisma.coordinateHistory.updateMany({
          where: { coordinateId: duplicateCoordinateId },
          data: { coordinateId: id },
        }),
        prisma.coordinate.delete({ where: { id: duplicateCoordinateId } }),
      ]);

      await coordinateRepo.recordHistory({
        coordinateId: id,
        actorType: "ADMIN",
        actorId: adminUser.sub,
        action: "MERGED",
        diffJson: { mergedFromId: duplicateCoordinateId },
      });

      await auditLogRepo.record({
        actorType: "ADMIN",
        actorId: adminUser.sub,
        entityType: "Coordinate",
        entityId: id,
        action: "MERGED",
        diffJson: { mergedFromId: duplicateCoordinateId },
      });

      const result = await coordinateRepo.findById(id);
      return reply.send(ok(result));
    }
  );
}
