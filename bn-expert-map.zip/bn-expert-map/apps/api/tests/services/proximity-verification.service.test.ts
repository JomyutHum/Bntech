import { describe, it, expect } from "vitest";
import {
  ProximityVerificationService,
  MissingLiveGpsReadingError,
} from "../../src/services/proximity-verification.service.js";

describe("ProximityVerificationService", () => {
  const service = new ProximityVerificationService(150);

  it("ACCEPTS when distance is well within the threshold", () => {
    const candidate = { latitude: 13.7563, longitude: 100.5018 };
    const driverLiveGps = { latitude: 13.75635, longitude: 100.50185 }; // ~7m away

    const result = service.verify(candidate, driverLiveGps);

    expect(result.outcome).toBe("ACCEPTED");
    expect(result.distanceMeters).toBeLessThan(150);
  });

  it("REJECTS when distance is well beyond the threshold", () => {
    const candidate = { latitude: 13.7563, longitude: 100.5018 };
    const driverLiveGps = { latitude: 13.8, longitude: 100.55 }; // several km away

    const result = service.verify(candidate, driverLiveGps);

    expect(result.outcome).toBe("REJECTED_TOO_FAR");
    expect(result.distanceMeters).toBeGreaterThan(150);
  });

  it("ACCEPTS at exactly the boundary (inclusive: distance <= threshold)", () => {
    // Construct two points exactly ~150m apart along a meridian.
    // 1 degree latitude ≈ 111,320 meters, so 150m ≈ 0.001347 degrees.
    const candidate = { latitude: 13.7563, longitude: 100.5018 };
    const deltaLat = 150 / 111320;
    const driverLiveGps = {
      latitude: candidate.latitude + deltaLat,
      longitude: candidate.longitude,
    };

    const result = service.verify(candidate, driverLiveGps);

    // Allow tiny floating point slack around the boundary; the key
    // documented behavior is inclusive (<=150 accepts).
    expect(result.distanceMeters).toBeCloseTo(150, 0);
    expect(["ACCEPTED", "REJECTED_TOO_FAR"]).toContain(result.outcome);
    if (result.distanceMeters <= 150) {
      expect(result.outcome).toBe("ACCEPTED");
    }
  });

  it("REJECTS just beyond the boundary", () => {
    const candidate = { latitude: 13.7563, longitude: 100.5018 };
    const deltaLat = 200 / 111320; // ~200m away
    const driverLiveGps = {
      latitude: candidate.latitude + deltaLat,
      longitude: candidate.longitude,
    };

    const result = service.verify(candidate, driverLiveGps);

    expect(result.outcome).toBe("REJECTED_TOO_FAR");
  });

  it("throws MissingLiveGpsReadingError when no live GPS reading is provided — never silently accepts", () => {
    const candidate = { latitude: 13.7563, longitude: 100.5018 };

    expect(() => service.verify(candidate, null)).toThrow(
      MissingLiveGpsReadingError
    );
  });
});
