import { describe, it, expect, vi, beforeEach } from "vitest";
import type { PrismaClient, Coordinate } from "@prisma/client";
import { CoordinateMatchingService } from "../../src/services/coordinate-matching.service.js";
import { buildNormalizedAddressKey } from "../../src/utils/address-normalizer.js";

function makeCoordinate(overrides: Partial<Coordinate>): Coordinate {
  const base: Coordinate = {
    id: "00000000-0000-0000-0000-000000000001",
    latitude: 13.7563,
    longitude: 100.5018,
    houseNumber: "123",
    moo: null,
    soi: "5",
    road: null,
    subdistrict: "บางนา",
    district: "บางนา",
    province: "กรุงเทพ",
    postalCode: null,
    placeType: "HOME",
    landmark: null,
    deliveryTimeNote: null,
    closedDays: null,
    remarks: null,
    tags: [],
    normalizedAddressKey: buildNormalizedAddressKey({
      soi: "5",
      houseNumber: "123",
      subdistrict: "บางนา",
      district: "บางนา",
      province: "กรุงเทพ",
    }),
    verificationSource: "LINE_LOCATION",
    verifiedByDriverId: null,
    verifiedByAdminId: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };
  return { ...base, ...overrides };
}

function makePrismaMock(coordinates: Coordinate[]) {
  return {
    coordinate: {
      findFirst: vi.fn(
        async ({ where }: { where: { normalizedAddressKey: string } }) => {
          return (
            coordinates.find(
              (c) => c.normalizedAddressKey === where.normalizedAddressKey
            ) ?? null
          );
        }
      ),
      findMany: vi.fn(async () => coordinates),
    },
  } as unknown as PrismaClient;
}

describe("CoordinateMatchingService", () => {
  let coordinates: Coordinate[];

  beforeEach(() => {
    coordinates = [];
  });

  it("returns EXACT_MATCH when the normalized address key matches exactly", async () => {
    const existing = makeCoordinate({});
    coordinates.push(existing);

    const service = new CoordinateMatchingService(makePrismaMock(coordinates));
    const result = await service.findMatch({
      soi: "5",
      houseNumber: "123",
      subdistrict: "บางนา",
      district: "บางนา",
      province: "กรุงเทพ",
    });

    expect(result.type).toBe("EXACT_MATCH");
    expect(result.exactMatch?.id).toBe(existing.id);
  });

  it("matches exactly even when abbreviations differ from the stored record", async () => {
    const existing = makeCoordinate({
      normalizedAddressKey: buildNormalizedAddressKey({
        soi: "5",
        houseNumber: "123",
        subdistrict: "ตำบลบางนา",
        district: "อำเภอบางนา",
        province: "กรุงเทพ",
      }),
    });
    coordinates.push(existing);

    const service = new CoordinateMatchingService(makePrismaMock(coordinates));
    const result = await service.findMatch({
      soi: "5",
      houseNumber: "123",
      subdistrict: "ต.บางนา",
      district: "อ.บางนา",
      province: "กรุงเทพ",
    });

    expect(result.type).toBe("EXACT_MATCH");
  });

  it("returns POSSIBLE_DUPLICATE for a fuzzy match within threshold", async () => {
    const existing = makeCoordinate({
      normalizedAddressKey: buildNormalizedAddressKey({
        soi: "5",
        houseNumber: "123",
        subdistrict: "บางนา",
        district: "บางนา",
        province: "กรุงเทพ",
      }),
    });
    coordinates.push(existing);

    const service = new CoordinateMatchingService(makePrismaMock(coordinates));
    // Same soi/subdistrict/district/province, house number formatted
    // slightly differently — should NOT be an exact key match, but should
    // be close enough to surface as a fuzzy candidate.
    const result = await service.findMatch({
      soi: "5",
      houseNumber: "123/1",
      subdistrict: "บางนา",
      district: "บางนา",
      province: "กรุงเทพ",
    });

    expect(result.type).toBe("POSSIBLE_DUPLICATE");
    expect(result.candidates?.[0]?.coordinate.id).toBe(existing.id);
  });

  it("returns NO_MATCH for a fuzzy match outside the similarity threshold", async () => {
    const existing = makeCoordinate({
      normalizedAddressKey: buildNormalizedAddressKey({
        soi: "5",
        houseNumber: "123",
        subdistrict: "บางนา",
        district: "บางนา",
        province: "กรุงเทพ",
      }),
    });
    coordinates.push(existing);

    const service = new CoordinateMatchingService(makePrismaMock(coordinates));
    const result = await service.findMatch({
      soi: "99",
      houseNumber: "456",
      subdistrict: "ลาดพร้าว",
      district: "ลาดพร้าว",
      province: "กรุงเทพ",
    });

    expect(result.type).toBe("NO_MATCH");
  });

  it("does NOT match purely on GPS proximity when address fields differ (next-door-neighbor case)", async () => {
    // Two unrelated houses 5 meters apart with completely different
    // house numbers / soi — must NOT be treated as the same address even
    // though GPS is extremely close.
    const existing = makeCoordinate({
      latitude: 13.75630,
      longitude: 100.50180,
      normalizedAddressKey: buildNormalizedAddressKey({
        soi: "1",
        houseNumber: "10",
        subdistrict: "บางนา",
        district: "บางนา",
        province: "กรุงเทพ",
      }),
    });
    coordinates.push(existing);

    const service = new CoordinateMatchingService(makePrismaMock(coordinates));
    const result = await service.findMatch(
      {
        soi: "8",
        houseNumber: "999",
        subdistrict: "บางนา",
        district: "บางนา",
        province: "กรุงเทพ",
      },
      { latitude: 13.75631, longitude: 100.50181 } // ~1-2m away
    );

    expect(result.type).not.toBe("EXACT_MATCH");
    // Address fields disagree too much (different soi + house number) to
    // even qualify as a fuzzy candidate, despite being GPS-adjacent.
    expect(result.type).toBe("NO_MATCH");
  });

  it("DOES match on address even when GPS is far away (address is primary)", async () => {
    // Same exact address fields, but GPS reading is far off (e.g. phone
    // GPS drift, or driver standing elsewhere) — address agreement alone
    // must still produce an exact match.
    const existing = makeCoordinate({
      latitude: 13.7563,
      longitude: 100.5018,
      normalizedAddressKey: buildNormalizedAddressKey({
        soi: "5",
        houseNumber: "123",
        subdistrict: "บางนา",
        district: "บางนา",
        province: "กรุงเทพ",
      }),
    });
    coordinates.push(existing);

    const service = new CoordinateMatchingService(makePrismaMock(coordinates));
    const result = await service.findMatch(
      {
        soi: "5",
        houseNumber: "123",
        subdistrict: "บางนา",
        district: "บางนา",
        province: "กรุงเทพ",
      },
      { latitude: 14.5, longitude: 101.5 } // far away (different province)
    );

    expect(result.type).toBe("EXACT_MATCH");
    expect(result.exactMatch?.id).toBe(existing.id);
  });

  it("returns NO_MATCH when no usable address fields are provided at all", async () => {
    const service = new CoordinateMatchingService(makePrismaMock([]));
    const result = await service.findMatch({});
    expect(result.type).toBe("NO_MATCH");
  });
});
