import { describe, it, expect } from "vitest";
import {
  LocationLinkResolverService,
  type ShortLinkResolver,
} from "../../src/services/location-link-resolver.service.js";

class FakeShortLinkResolver implements ShortLinkResolver {
  constructor(private readonly resolvedUrl: string | null) {}
  async resolveRedirect(): Promise<string | null> {
    return this.resolvedUrl;
  }
}

describe("LocationLinkResolverService — provider detection", () => {
  const service = new LocationLinkResolverService();

  it("detects a Google Maps short link", () => {
    expect(
      service.detectProvider("https://maps.app.goo.gl/abC123xYz")
    ).toBe("GOOGLE_SHORT");
  });

  it("detects a Google Maps full link", () => {
    expect(
      service.detectProvider(
        "https://www.google.com/maps/place/Some+Place/@13.7563,100.5018,17z"
      )
    ).toBe("GOOGLE_FULL");
  });

  it("detects an Apple Maps link", () => {
    expect(
      service.detectProvider("https://maps.apple.com/?ll=13.7563,100.5018")
    ).toBe("APPLE_MAPS");
  });

  it("detects a Waze link", () => {
    expect(
      service.detectProvider("https://www.waze.com/ul?ll=13.7563%2C100.5018")
    ).toBe("WAZE");
  });

  it("returns UNKNOWN for an unrecognized/malformed link", () => {
    expect(service.detectProvider("hello, I am at my house")).toBe(
      "UNKNOWN"
    );
    expect(service.detectProvider("https://example.com/not-a-map")).toBe(
      "UNKNOWN"
    );
  });
});

describe("LocationLinkResolverService — coordinate extraction", () => {
  it("extracts lat/lng from a Google full link with @lat,lng pattern", async () => {
    const service = new LocationLinkResolverService();
    const result = await service.resolveLink(
      "https://www.google.com/maps/place/Some+Place/@13.7563,100.5018,17z"
    );

    expect(result.provider).toBe("GOOGLE_FULL");
    expect(result.coordinate).not.toBeNull();
    expect(result.coordinate?.latitude).toBeCloseTo(13.7563, 4);
    expect(result.coordinate?.longitude).toBeCloseTo(100.5018, 4);
  });

  it("extracts lat/lng from a Google full link with ?q=lat,lng pattern", async () => {
    const service = new LocationLinkResolverService();
    const result = await service.resolveLink(
      "https://www.google.com/maps?q=13.7563,100.5018"
    );

    expect(result.coordinate?.latitude).toBeCloseTo(13.7563, 4);
    expect(result.coordinate?.longitude).toBeCloseTo(100.5018, 4);
  });

  it("extracts lat/lng from an Apple Maps ll= link", async () => {
    const service = new LocationLinkResolverService();
    const result = await service.resolveLink(
      "https://maps.apple.com/?ll=13.7563,100.5018&q=Dropped+Pin"
    );

    expect(result.provider).toBe("APPLE_MAPS");
    expect(result.coordinate?.latitude).toBeCloseTo(13.7563, 4);
    expect(result.coordinate?.longitude).toBeCloseTo(100.5018, 4);
  });

  it("extracts lat/lng from a Waze ll= link", async () => {
    const service = new LocationLinkResolverService();
    const result = await service.resolveLink(
      "https://www.waze.com/ul?ll=13.756300,100.501800&navigate=yes"
    );

    expect(result.provider).toBe("WAZE");
    expect(result.coordinate?.latitude).toBeCloseTo(13.7563, 4);
    expect(result.coordinate?.longitude).toBeCloseTo(100.5018, 4);
  });

  it("extracts lat/lng from a Waze to=ll. link", async () => {
    const service = new LocationLinkResolverService();
    const result = await service.resolveLink(
      "https://www.waze.com/live-map/directions?to=ll.13.7563%2C100.5018"
    );

    expect(result.provider).toBe("WAZE");
    expect(result.coordinate?.latitude).toBeCloseTo(13.7563, 4);
    expect(result.coordinate?.longitude).toBeCloseTo(100.5018, 4);
  });

  it("resolves a Google short link via the injected redirect resolver", async () => {
    const fakeResolver = new FakeShortLinkResolver(
      "https://www.google.com/maps/place/Resolved/@13.7563,100.5018,17z"
    );
    const service = new LocationLinkResolverService(fakeResolver);

    const result = await service.resolveLink(
      "https://maps.app.goo.gl/abC123xYz"
    );

    expect(result.provider).toBe("GOOGLE_SHORT");
    expect(result.coordinate?.latitude).toBeCloseTo(13.7563, 4);
    expect(result.coordinate?.longitude).toBeCloseTo(100.5018, 4);
  });

  it("returns null coordinate when short link redirect resolution fails", async () => {
    const fakeResolver = new FakeShortLinkResolver(null);
    const service = new LocationLinkResolverService(fakeResolver);

    const result = await service.resolveLink(
      "https://maps.app.goo.gl/abC123xYz"
    );

    expect(result.provider).toBe("GOOGLE_SHORT");
    expect(result.coordinate).toBeNull();
  });

  it("returns null coordinate and UNKNOWN provider for a malformed/unrecognized URL", async () => {
    const service = new LocationLinkResolverService();
    const result = await service.resolveLink("this is just plain text");

    expect(result.provider).toBe("UNKNOWN");
    expect(result.coordinate).toBeNull();
  });
});
