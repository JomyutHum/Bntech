import { describe, it, expect } from "vitest";
import {
  buildNormalizedAddressKey,
  fuzzyAddressSimilarity,
  parseRawAddressText,
} from "../../src/utils/address-normalizer.js";
import { haversineDistanceMeters } from "../../src/utils/geo.js";

describe("buildNormalizedAddressKey", () => {
  it("builds a consistent key regardless of abbreviation usage", () => {
    const keyWithAbbr = buildNormalizedAddressKey({
      soi: "สุขใจ 5",
      road: "ถ.สุขุมวิท",
      moo: "ม.3",
      houseNumber: "123/45",
      subdistrict: "ต.บางนา",
      district: "อ.บางนา",
      province: "กรุงเทพ",
    });

    const keyFullWords = buildNormalizedAddressKey({
      soi: "สุขใจ 5",
      road: "ถนนสุขุมวิท",
      moo: "หมู่3",
      houseNumber: "123/45",
      subdistrict: "ตำบลบางนา",
      district: "อำเภอบางนา",
      province: "กรุงเทพ",
    });

    expect(keyWithAbbr).toBe(keyFullWords);
  });

  it("returns an empty string when no fields are provided", () => {
    expect(buildNormalizedAddressKey({})).toBe("");
  });

  it("collapses extra whitespace and lowercases", () => {
    const key = buildNormalizedAddressKey({
      houseNumber: "  123  ",
      province: "Bangkok",
    });
    expect(key).toBe("123|bangkok");
  });
});

describe("fuzzyAddressSimilarity", () => {
  it("returns 1 for identical keys", () => {
    const key = buildNormalizedAddressKey({
      soi: "5",
      houseNumber: "10",
      province: "กรุงเทพ",
    });
    expect(fuzzyAddressSimilarity(key, key)).toBe(1);
  });

  it("returns 0 for completely different keys", () => {
    const keyA = buildNormalizedAddressKey({
      soi: "5",
      province: "กรุงเทพ",
    });
    const keyB = buildNormalizedAddressKey({
      soi: "99",
      province: "เชียงใหม่",
    });
    expect(fuzzyAddressSimilarity(keyA, keyB)).toBe(0);
  });

  it("returns a partial score for partially overlapping keys", () => {
    const keyA = buildNormalizedAddressKey({
      soi: "5",
      houseNumber: "10",
      province: "กรุงเทพ",
    });
    const keyB = buildNormalizedAddressKey({
      soi: "5",
      houseNumber: "10",
      province: "เชียงใหม่",
    });
    const score = fuzzyAddressSimilarity(keyA, keyB);
    expect(score).toBeGreaterThan(0);
    expect(score).toBeLessThan(1);
  });

  it("returns 0 when either key is empty", () => {
    expect(fuzzyAddressSimilarity("", "abc")).toBe(0);
    expect(fuzzyAddressSimilarity("abc", "")).toBe(0);
  });
});

describe("parseRawAddressText", () => {
  it("extracts common Thai address fields from label text", () => {
    const raw =
      "ส่งถึง: สมชาย ใจดี บ้านเลขที่ 99/1 หมู่ 4 ซอย สุขใจ ถนน พระราม 2 " +
      "ตำบล บางบอน อำเภอ บางบอน จังหวัด กรุงเทพ 10150";

    const fields = parseRawAddressText(raw);

    expect(fields.houseNumber).toBe("99/1");
    expect(fields.moo).toBe("4");
    expect(fields.soi).toBe("สุขใจ");
    expect(fields.road).toBe("พระราม 2");
    expect(fields.subdistrict).toBe("บางบอน");
    expect(fields.district).toBe("บางบอน");
    expect(fields.province).toBe("กรุงเทพ");
  });

  it("leaves fields undefined rather than guessing when not present", () => {
    const fields = parseRawAddressText("ข้อความที่ไม่มีที่อยู่อะไรเลย");
    expect(fields.houseNumber).toBeUndefined();
    expect(fields.moo).toBeUndefined();
    expect(fields.province).toBeUndefined();
  });
});

describe("haversineDistanceMeters", () => {
  it("returns 0 for identical points", () => {
    const point = { latitude: 13.7563, longitude: 100.5018 };
    expect(haversineDistanceMeters(point, point)).toBeCloseTo(0, 1);
  });

  it("computes a realistic distance between two known Bangkok points", () => {
    // Siam Paragon area vs. Asok area — roughly ~2.5km apart.
    const siam = { latitude: 13.7466, longitude: 100.5347 };
    const asok = { latitude: 13.7375, longitude: 100.5604 };
    const distance = haversineDistanceMeters(siam, asok);
    expect(distance).toBeGreaterThan(2000);
    expect(distance).toBeLessThan(3500);
  });

  it("is symmetric", () => {
    const a = { latitude: 13.75, longitude: 100.5 };
    const b = { latitude: 13.76, longitude: 100.52 };
    expect(haversineDistanceMeters(a, b)).toBeCloseTo(
      haversineDistanceMeters(b, a),
      6
    );
  });
});
