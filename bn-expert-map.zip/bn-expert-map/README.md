# BN Expert Map

Logistics coordinate database & playlist platform for delivery drivers and
logistics companies. Built around two core assets:

1. **Coordinate Database** — a growing, human-verified database of
   delivery addresses mapped to exact GPS coordinates.
2. **Playlist Engine** — nearest-first delivery route management per
   driver per day.

The single most important rule in this system: **coordinates are never
guessed**. OCR extracts addresses only; a coordinate is only ever saved as
verified once a driver confirms it while physically near the location (via
LINE Location share or a map link, cross-checked against their live GPS —
see `apps/api/src/services/proximity-verification.service.ts`).

## Project structure

```
apps/
  api/      Fastify + TypeScript backend (Prisma, business logic, LINE bot)
  web/      Next.js 15 frontend — serves both the Admin dashboard and the
            Driver-facing web app from one codebase
packages/
  shared/   Shared Zod schemas, enums, and types used by both apps
```

## Getting started (local development)

```bash
# 1. Install dependencies
npm install

# 2. Copy env files and fill in REQUIRES_USER_SETUP values
cp apps/api/.env.example apps/api/.env
cp apps/web/.env.example apps/web/.env.local

# 3. Start Redis (Postgres is Supabase-managed — no local container needed)
docker compose up -d redis

# 4. Run database migrations against your Supabase Postgres
npm run prisma:migrate

# 5. (Optional) seed an initial admin user
npm run --workspace=apps/api prisma:seed

# 6. Run both apps
npm run dev:api    # http://localhost:4000
npm run dev:web    # http://localhost:3000
```

## Testing

```bash
npm run test              # unit tests for the API (Vitest)
npm run test:coverage     # with coverage report
```

The most safety-critical logic — `CoordinateMatchingService` (address-first
matching) and `ProximityVerificationService` (the 150m GPS check that
gates every new coordinate) — has dedicated unit tests covering exact
match, fuzzy match, the next-door-neighbor GPS-proximity-without-address
case, and the missing-GPS-reading case. See `apps/api/tests/services/`.

## Deployment

See [`DEPLOYMENT.md`](./DEPLOYMENT.md) for the full, concrete deployment
guide (Vercel for the frontend, Fly.io for the backend + Redis, Supabase
for Postgres + Storage, Cloudflare for DNS/CDN).

## Documentation

- [`DEPLOYMENT.md`](./DEPLOYMENT.md) — deployment steps and environment
  variable checklist
- `apps/api/.env.example`, `apps/web/.env.example` — every required env
  var, with a comment on where to obtain each one
